# Cuenta y copia privada

Athlete Club funciona entero sin cuenta (modo invitado): registro, historial, estadísticas y rutinas viven en Room, en el
móvil. Con cuenta, esos datos se copian en un espacio **privado** de Firestore y se pueden recuperar al reinstalar.

## 1. Activar la autenticación (Firebase Console)

1. Crea (o reutiliza) el proyecto Firebase que ya usa Club y registra una app Android con el paquete **`app.fuckrun`**
   (es el `applicationId` que se conserva).
2. *Authentication → Sign-in method*: activa **Correo electrónico/contraseña**. Mantén activado **Anónimo** para que los
   perfiles de Club creados con versiones anteriores sigan funcionando (al crear cuenta se vinculan y conservan su uid).
3. *Authentication → Templates*: revisa en español los correos de **verificación** y **restablecimiento de contraseña**.
4. Copia en `local.properties` (ver `local.properties.example`):
   ```
   FIREBASE_API_KEY=...
   FIREBASE_APP_ID=...
   FIREBASE_PROJECT_ID=...
   ```
   Sin estas claves la app muestra «La cuenta no está configurada» y sigue funcionando en local.

## 2. Desplegar las reglas de acceso

```bash
npm i -g firebase-tools
firebase login
firebase use <tu-proyecto>
firebase deploy --only firestore:rules     # usa firebase/firestore.rules
```

Las reglas garantizan:
- `private/{uid}/…` solo lo lee y escribe su dueño, y solo con una cuenta de correo (no un perfil anónimo).
- `sessions/`, `invites/` y `users/{uid}/joined` son de Club y nunca contienen actividades personales.
- Un organizador ve asistentes y confirmaciones, pero **no** puede leer `private/` de nadie.

Prueba recomendada con el emulador de reglas: leer `private/B/activities/x` autenticado como A debe fallar.

## 3. Modelo de la copia

```
private/{uid}/activities/{syncId}             resumen, deporte, nota, eventos de pausa; complete=true se escribe AL FINAL
private/{uid}/activities/{syncId}/chunks/{i}  puntos GPS en bloques de 400
private/{uid}/routines/{syncId}               rutinas
private/{uid}/planned/{syncId}                sesiones planificadas (vínculo con rutina y actividad por syncId)
private/{uid}/favorites/{routeId}             favoritos
private/{uid}/tombstones/{key}                borrados (nunca se recupera lo eliminado)
private/{uid}/meta/settings                   formulario y preferencias (gana la versión más reciente)
```

- **Sin duplicados**: los documentos usan el `syncId` estable de cada fila (UUID creado en la migración v1→v2 para lo antiguo).
- **«Sincronizado»** solo cuando el servidor ha confirmado todo, incluidos los bloques de puntos. Si no, «Pendiente de conexión»
  o «Error · Reintentar», con la fecha de la última copia confirmada.
- **Restaurar**: se descargan todos los bloques de una actividad, se comprueba el número de puntos y se inserta en una transacción;
  después se **recalculan los totales** a partir de los puntos y eventos restaurados.
- **Aislamiento**: cada cuenta tiene su propia base local (`athlete-<uid>.db`) y sus preferencias; el invitado conserva
  `fuckrun-personal.db`. Cambiar de cuenta no mezcla datos. No se puede cambiar de cuenta con una actividad en curso.
- **Invitado → cuenta**: se ofrece «Guardar mis actividades en esta cuenta (N)». Solo se copian si se confirma; después se
  quitan del perfil invitado para no duplicarlas.
- **Privacidad**: la contraseña la gestiona Firebase Authentication (la app no la guarda). Las coordenadas no se escriben en
  registros de diagnóstico.

## 4. Prueba obligatoria de recuperación (pendiente de ejecutar en dispositivo)

1. Crear cuenta → verificar correo.
2. Registrar una actividad con recorrido (≥ 2 min al aire libre) y escribir una nota. Guardar.
3. Crear una rutina con una sesión y marcar una ruta como favorita.
4. Perfil → esperar «Sincronizado» (con fecha).
5. Desinstalar. Reinstalar. «Iniciar sesión» con la misma cuenta.
6. Verificar: puntos del mapa, deporte, tiempos, nota, plan, favorito y totales de Progreso.
7. Repetir con modo avión durante el entrenamiento: al guardar debe decir «Pendiente de conexión»; al recuperar conexión,
   «Sincronizado».
8. Entrar con OTRA cuenta en otro móvil: no debe ver nada de la primera.
