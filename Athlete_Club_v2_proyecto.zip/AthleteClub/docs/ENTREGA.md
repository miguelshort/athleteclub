# Entrega · Athlete Club 2.0.0

## Qué se ha podido verificar aquí y qué no

El entorno donde se ha hecho la actualización **no tiene Android SDK ni acceso a los repositorios de Google/Maven**.
Por eso:

| Comprobación | Estado |
|---|---|
| Compilar el APK (`./gradlew assembleDebug`) | **No ejecutado**. Hay que compilar en Android Studio. |
| Pruebas en dispositivo o emulador (recorridos 1–7) | **Pendientes**. Ninguna se ha ejecutado. |
| Reproducir el cierre y capturar la traza con Logcat | **No ejecutado** (sin dispositivo). Ver «Cierre al empezar». |
| Capturas de ambos temas | **No generadas** (sin dispositivo). |
| Lógica de dominio (métricas, deportes, desnivel, recomendaciones) | **Compilada y probada**: 19/19 pruebas correctas con el compilador Kotlin 2.0.21. |
| Migración de Room v1 → v2 | **Probada en SQLite** sobre el esquema v1: todas las carreras quedan como `RUN`, con `syncId` UUID único y pendientes de copia. |
| Equilibrio sintáctico de todos los `.kt` | Revisado automáticamente: sin desequilibrios. |

El código de interfaz (Compose), Firebase y el servicio no se han podido compilar: es posible que Android Studio señale
algún error menor de tipos o importaciones. Conviene compilar primero y corregir lo que indique antes de probar.

## Cierre al empezar una actividad

No se ha podido obtener la traza real. Se han revisado `MapView.kt`, `PreRunScreen.kt`, `ActiveRunScreen.kt`,
`TrackingService.kt` y `AndroidManifest.xml`, y se han corregido todas las causas plausibles encontradas:

1. **Mapa (`MapView.kt`)**: el arreglo de `DisposableEffect` ya estaba aplicado en el ZIP y se conserva: el observador solo
   existe con una instancia, se elimina al cambiar de instancia o de ciclo de vida y nunca llama a `onDetach()`; la instancia
   se libera una sola vez en `onRelease`. Se protegen además `animateTo`, `setCenter` y el ajuste de encuadre con 0, 1 o varios puntos.
2. **Arranque del servicio desde segundo plano**: la cuenta atrás seguía corriendo con la app oculta (p. ej. al abrir la
   música) y al llegar a 0 llamaba a `startForegroundService`; en Android 12+ eso lanza `ForegroundServiceStartNotAllowedException`
   y cierra la app. Ahora la cuenta atrás se pausa si la app no está visible y `Tracking.start` nunca lanza: devuelve el motivo.
3. **`startForeground` sin protección**: en Android 14+ lanza `SecurityException` si falta el permiso. Ahora se captura, se informa
   («Permitir ubicación», «Reintentar») y **no se crea ninguna actividad**.
4. **Proveedor GPS inexistente**: `requestLocationUpdates(GPS_PROVIDER)` lanza `IllegalArgumentException` en dispositivos sin GPS;
   solo se capturaba `SecurityException`. Ahora se prueba GPS → combinado → red.
5. **Ubicación solo aproximada**: el botón quedaba desactivado sin explicación. Ahora se pide la ubicación precisa o se abre Ajustes.
6. **Doble toque**: podía crear dos sesiones. Ahora un estado `Starting` y el servicio ignoran el segundo inicio.
7. **Navegación prematura**: el registro se abría antes de que el servicio confirmara. Ahora se espera a `StartState.Started`.

Cuando se pruebe en el dispositivo, si el cierre persiste, capturar con:
`adb logcat -b crash -d` y `adb logcat AndroidRuntime:E *:S` tras «Inicio → Empezar actividad → Empezar», y anotar en qué
momento ocurre (preparación, arranque del servicio o aparición del mapa).

Versiones del proyecto: `minSdk 26`, `targetSdk 35`, `compileSdk 35`.

## Qué cambia (por apartado del encargo)

1. **Proyecto existente**: se conservan Kotlin, Compose, Room, DataStore, servicio nativo de ubicación, osmdroid, Haze y Firebase.
   Nombre «Athlete Club» en lanzador, bienvenida, interfaz, notificaciones, invitaciones y exportaciones. `applicationId` y firma
   intactos; migración v1→v2; enlaces `fuckrun://join/…` siguen funcionando y se añaden `athleteclub://join/…`. Icono: ver `docs/MARCA.md`.
2. **Camino principal**: Inicio con «Tu próxima actividad», selector de deporte con pictograma y chevrón, «Empezar actividad»,
   resumen semanal y próxima sesión; con actividad en curso, «Volver a la actividad» con el tiempo en directo. Preparación con
   deporte, «Música», GPS y «Empezar»; origen y cuenta atrás en «Más opciones»; precarga desde ruta, rutina o encuentro.
   Registro con cifra grande por deporte, dos secundarias, mapa, «Ver métricas», bloquear, pausar, terminar y minimizar.
3. **Dirección visual**: paletas claro/oscuro (#0B0C0F / #15171C en oscuro), acentos coral, bosque, azul y ámbar ajustados por tema;
   verde Empezar/Reanudar, rojo Pausar, azul Terminar, #6C8CFF en gráficas. Inter Regular 400 en todo con −0,08 em; se han retirado
   del APK los pesos Medium/SemiBold/Bold para que nada pueda salir en otro peso. Apariencia: Claro, Oscuro y Automático (por defecto).
4. **Barra y menús**: cápsula de vidrio con lente de color en el activo; `GlassStyle` pasa del 70 % al 42 % (oscuro) / 55 % (claro),
   radio 32 dp, filo de luz y sombra corta. `SheetHost` ya no coloca todo abajo: los menús nacen del control pulsado (debajo,
   encima o hacia dentro), diálogos centrados solo para confirmaciones, formularios largos a pantalla completa. Componente táctil común.
5. **Cierre al empezar**: ver arriba.
6. **Música**: Spotify, Apple Music, Amazon Music y «Sin música»; «Abrir …» en la propia fila; web, instalar u otra opción si falta.
   No se guardan credenciales y nunca se muestra «Reproduciendo» (no hay integración autorizada).
7. **Cuenta y copia**: Firebase Authentication (correo/contraseña, verificación, recuperación, cierre de sesión, eliminación) y copia
   privada por tramos con borrados registrados. Ver `docs/CUENTA.md`.
8. **Tutorial**: 9 láminas con el guion del encargo, Atrás/Siguiente/Saltar, indicador y «Empezar a usar Athlete Club»; se guarda
   como visto en el dispositivo y se repite desde Perfil → Cómo se usa. Indicaciones de un paso en registro manual, invitar,
   cambiar la métrica, exportar y descartar.
9. **Funciones deportivas**: formulario por deporte, plantillas propias para Sendero, Bicicleta y Caminata, filtros por deporte en
   Rutas y Progreso, deporte en rutinas, encuentros, registros manuales, resúmenes y exportaciones; umbrales GPS por deporte
   (adiós al límite global de 45 km/h) y desnivel solo con medición fiable.

## Desviaciones y limitaciones conocidas

- **Tutorial**: las láminas no usan capturas de pantalla (no había dispositivo para hacerlas). Muestran los **componentes reales**
  de esta versión (los mismos que la app, en el tema activo e inertes al toque), con el control resaltado. Si se prefieren
  capturas, se pueden sustituir lámina a lámina en `TutorialScreen.kt`.
- **Foco tras cerrar un menú**: el menú se cierra con toque fuera, Atrás o selección, pero no se devuelve explícitamente el foco
  de TalkBack al control que lo abrió.
- **Apple Music en Android** depende de que la app exista en el dispositivo/región; si no, se ofrece la web.
- **Avisos de Club con la app cerrada** siguen requiriendo FCM + Cloud Functions (`docs/SERVICIOS.md`).
- **Desnivel**: depende de que el móvil dé precisión vertical; en muchos móviles sin barómetro se mostrará «—».
- **Imágenes de referencia de iOS**: no llegaron con el encargo; el material se ha diseñado a partir de la descripción escrita.

## Recorridos de aceptación (todos pendientes de ejecutar en dispositivo)

1. Instalar → tutorial (seguir u omitir) → elegir deporte → empezar, pausar, minimizar, volver, terminar y guardar. Con los
   cuatro deportes y entrando desde Rutas, Rutinas y Club. Doble toque en «Empezar» = una sola actividad.
2. Sin cobertura, GPS apagado, permiso denegado y luego concedido, señal pendiente, notificaciones rechazadas, volver de Ajustes.
3. Menús desde arriba de Inicio, borde inferior de una lista y lateral del mapa; pulsación breve, mantenida, cancelada y scroll.
4. Cambiar Claro/Oscuro/Automático con un menú o una actividad abiertos; Inter Regular y −0,08 em con letra ampliada
   («00:00», «3,25 km», «Sendero» sin recortes).
5. Cada proveedor musical con y sin la app; volver antes de iniciar y durante el registro.
6. Actualizar sobre la versión antigua con historial; crear cuenta desde invitado; sincronizar sin duplicados; reinstalar y
   restaurar; otra cuenta no ve esos datos (`docs/CUENTA.md`, §4).
7. Reabrir el tutorial desde Perfil y cotejarlo con la versión entregada.
