# Exportación de datos propios

Antes de compartir cualquier archivo, la app avisa de que un archivo de ruta puede revelar ubicaciones personales.

## GPX (por actividad)
GPX 1.1 estándar. Un `<trkseg>` por segmento registrado; los huecos (pausas, pérdida de señal, cierre de la app) **no** se rellenan. Incluye hora y altitud cuando existe.

## JSON `athlete-club-export` v2 (antes `fuckrun-export` v1)
```json
{
  "format": "fuckrun-export",
  "version": 1,
  "exportedAt": 1763490000000,
  "settings": { "...": "respuestas del formulario y ajustes (solo en la exportación completa)" },
  "runs": [{
    "id": 1, "startedAt": 0, "endedAt": 0,
    "source": "GPS | MANUAL", "kind": "FREE | ROUTINE | ROUTE | SHARED",
    "distanceM": 0.0, "elapsedMs": 0, "activeMs": 0,
    "avgSpeedMps": 0.0, "maxSpeedMps": 0.0, "minMovingSpeedMps": 0.0,
    "lostMs": 0, "note": "", "plannedSessionId": null,
    "points": [{ "segment": 0, "time": 0, "lat": 0.0, "lon": 0.0, "accuracyM": 5.0, "altitudeM": null }]
  }],
  "planned": [{ "id": 1, "routineId": 1, "name": "", "epochDay": 0, "type": "EASY", "targetMinutes": 30, "targetKm": null, "linkedRunId": null }]
}
```
Tiempos en milisegundos desde época Unix (UTC). Velocidades en m/s. Valores `null` = sin datos suficientes. La exportación de una sola actividad no incluye ajustes.


### Cambios en la versión 2
- Cada actividad incluye `sport` (`RUN`, `HIKE`, `BIKE`, `WALK`), `elevationGainM` (o `null`) y `syncId` (identificador estable).
- Cada sesión planificada incluye `sport`.
- El GPX usa `<type>` según el deporte (`running`, `hiking`, `cycling`, `walking`) y `creator="Athlete Club"`.
- Antes de compartir se avisa de que un GPX revela el recorrido.
