# Catálogo de recorridos verificados

La app **no inventa** calles, senderos, distancias, accesibilidad ni condiciones de seguridad. Un mapa por sí solo no demuestra que un recorrido sea adecuado para correr. Por eso el catálogo (`app/src/main/assets/routes/`) se publica vacío y la app muestra «Todavía no tenemos recorridos verificados para esta zona» junto a una sesión por tiempo o distancia.

## Proceso de verificación (por recorrido)
1. **Fuente con licencia compatible**: datos de OpenStreetMap (ODbL, citar), datos abiertos municipales o del CNIG/IGN (normalmente CC BY 4.0), o trazado propio grabado sobre el terreno.
2. **Revisión**: recorrer o validar el trazado; medir la distancia sobre la geometría final.
3. **Atributos**: superficie y desnivel solo con dato fiable (si no, `null` → «Sin dato verificado»). «Iluminada», «accesible», etc. solo en `verifiedAttributes` si se han comprobado.
4. **Incidencias** conocidas (obras, cierres, horarios de parques) con fecha.
5. Registrar fuente y fecha de revisión. Revisar periódicamente.

## Esquema (un archivo .json por recorrido)
```json
{
  "id": "slug-unico",
  "name": "Nombre",
  "municipality": "Municipio (como en municipios.csv)",
  "province": "Provincia",
  "cpro": "28",
  "shape": "LOOP | OUT_BACK",
  "distanceM": 5000.0,
  "surface": "tierra compactada | asfalto | null",
  "elevationGainM": null,
  "start": { "lat": 0.0, "lon": 0.0, "label": "Descripción del punto de inicio" },
  "track": [ { "lat": 0.0, "lon": 0.0 } ],
  "environments": ["PARK", "CITY", "SEAFRONT", "TRAILS"],
  "source": { "name": "OpenStreetMap", "license": "ODbL 1.0", "url": "https://www.openstreetmap.org/..." },
  "reviewedAt": "AAAA-MM-DD",
  "incidents": [ { "text": "Tramo cerrado por obras", "date": "AAAA-MM-DD" } ],
  "verifiedAttributes": []
}
```
`cpro` y `municipality` sirven para distinguir localidades con el mismo nombre.

## Ordenación y filtros
Filtros: distancia, superficie, desnivel (solo con dato fiable) y cercanía (si el usuario comparte ubicación, que es opcional). Orden: entorno preferido (+2), forma preferida (+1), llano si se prefiere y hay dato (+1), después cercanía. La app muestra este criterio en pantalla.
