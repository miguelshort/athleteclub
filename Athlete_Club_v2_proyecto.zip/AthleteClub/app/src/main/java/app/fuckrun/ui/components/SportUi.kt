package app.fuckrun.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.fuckrun.domain.Sport
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T

/** Pictogramas: figura corriendo (coral), bota de montaña (bosque), bicicleta (azul) y figura andando (ámbar). */
val Sport.icon: ImageVector get() = when (this) {
    Sport.RUN -> Icons.Rounded.DirectionsRun
    Sport.HIKE -> Icons.Rounded.Hiking
    Sport.BIKE -> Icons.Rounded.DirectionsBike
    Sport.WALK -> Icons.Rounded.DirectionsWalk
}

/** Acento del deporte ajustado a la luminosidad del tema (variantes más oscuras en claro). */
val Sport.color: Color get() = when (this) {
    Sport.RUN -> C.Coral
    Sport.HIKE -> C.Forest
    Sport.BIKE -> C.Sky
    Sport.WALK -> C.Amber
}

@Composable
fun SportBadge(sport: Sport, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(sport.color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        Icon(sport.icon, null, tint = sport.color, modifier = Modifier.size(size * 0.58f))
    }
}

/**
 * Selector de deporte: pictograma grande, nombre y chevrón en el propio control. Al tocarlo se despliega
 * el menú desde aquí mismo con los cuatro deportes (pictograma, nombre y marca de selección).
 */
@Composable
fun SportSelector(sport: Sport, modifier: Modifier = Modifier, enabled: Boolean = true, onChange: (Sport) -> Unit) {
    val sheet = LocalSheet.current
    Row(
        modifier.fillMaxWidth().heightIn(min = 76.dp)
            .liquid(RoundedCornerShape(24.dp), sport.color.copy(alpha = 0.12f), enabled = enabled, role = Role.DropdownList,
                onClickLabel = "Cambiar deporte") {
                sheet.pick("Deporte", Sport.entries, { it.label }, sport, icon = { it.icon }, tint = { it.color }) { onChange(it) }
            }
            .semantics { contentDescription = "Deporte: ${sport.label}. Toca para cambiar" }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SportBadge(sport, 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Deporte", style = T.Label)
            Text(sport.label, style = T.Section.copy(color = C.Text))
        }
        if (enabled) Icon(Icons.Rounded.ExpandMore, null, tint = sport.color, modifier = Modifier.size(30.dp))
    }
}
