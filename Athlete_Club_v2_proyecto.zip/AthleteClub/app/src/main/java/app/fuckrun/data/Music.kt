package app.fuckrun.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Apertura de proveedores musicales con mecanismos públicos de Android: intent de lanzamiento del paquete instalado,
 * su página web si no lo está, o la ficha de la tienda para instalarla. Athlete Club no recibe ni guarda credenciales,
 * ni consulta qué se reproduce: no existe una integración autorizada, así que nunca se muestra «Reproduciendo».
 * Los paquetes se declaran en <queries> del manifiesto (visibilidad de paquetes, Android 11+).
 */
object Music {
    data class Info(val pkg: String, val web: String, val openLabel: String)

    fun info(p: MusicProvider): Info? = when (p) {
        MusicProvider.SPOTIFY -> Info("com.spotify.music", "https://open.spotify.com/", "Abrir Spotify")
        MusicProvider.APPLE -> Info("com.apple.android.music", "https://music.apple.com/", "Abrir Apple Music")
        MusicProvider.AMAZON -> Info("com.amazon.mp3", "https://music.amazon.es/", "Abrir Amazon Music")
        MusicProvider.NONE -> null
    }

    fun isInstalled(ctx: Context, p: MusicProvider): Boolean {
        val i = info(p) ?: return false
        return ctx.packageManager.getLaunchIntentForPackage(i.pkg) != null
    }

    sealed interface Result { data object Opened : Result; data object NotInstalled : Result; data class Failed(val reason: String) : Result }

    /** Abre la app del proveedor en su propia tarea; al volver, Athlete Club conserva la preparación. */
    fun open(ctx: Context, p: MusicProvider): Result {
        val i = info(p) ?: return Result.Failed("Sin proveedor")
        val launch = ctx.packageManager.getLaunchIntentForPackage(i.pkg) ?: return Result.NotInstalled
        return try {
            ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Result.Opened
        } catch (e: ActivityNotFoundException) { Result.NotInstalled } catch (e: SecurityException) { Result.Failed("El sistema no ha permitido abrirla") }
    }

    fun openWeb(ctx: Context, p: MusicProvider): Boolean {
        val i = info(p) ?: return false
        return runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(i.web)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)
    }

    fun openStore(ctx: Context, p: MusicProvider): Boolean {
        val i = info(p) ?: return false
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${i.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${i.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { ctx.startActivity(market); true }.recoverCatching { ctx.startActivity(web); true }.getOrDefault(false)
    }
}
