package app.fuckrun.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.Sport
import app.fuckrun.data.AppSettings
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/** Actividad introducida a mano: sin ruta GPS, sin máximos ni mínimos. Se distingue de las medidas. */
@Composable
fun ManualActivityScreen(nav: NavController) {
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    var day by remember { mutableStateOf(LocalDate.now()) }
    var hour by remember { mutableIntStateOf(8) }
    var minutes by remember { mutableStateOf("") }
    var km by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var sport by remember { mutableStateOf<Sport?>(null) }
    val sp = sport ?: settings.lastFreeSport
    val mins = minutes.toIntOrNull()
    val dist = km.replace(',', '.').toDoubleOrNull()
    val valid = mins != null && mins in 1..1440 && (km.isBlank() || (dist != null && dist > 0 && dist < 400))

    ScreenScaffold("Añadir manual") {
        if ("manual" !in settings.hintsSeen) item {
            Hint("Usa el registro manual para algo que hiciste sin el móvil. Se guarda marcado como «Introducida a mano».") {
                scope.launch { g.profile.update { it.copy(hintsSeen = it.hintsSeen + "manual") } }
            }
        }
        item { SportSelector(sp) { sport = it } }
        item { Notice("Las actividades manuales contienen solo los datos que introduces: sin ruta GPS ni velocidades máxima o mínima.") }
        item {
            FCard {
                ListRow("Fecha", Fmt.dateLong(day), onClick = {
                    sheet.pick("Fecha", (0..30).map { LocalDate.now().minusDays(it.toLong()) }, { Fmt.dateLong(it) }, day) { day = it }
                })
                ListRow("Hora de inicio", "%02d:00".format(hour), onClick = {
                    sheet.pick("Hora de inicio", (5..23).toList(), { "%02d:00".format(it) }, hour) { hour = it }
                })
            }
        }
        item { Text("Duración (minutos)", style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp)) }
        item { Field(minutes, "Por ejemplo, 35", singleLine = true) { minutes = it.filter(Char::isDigit).take(4) } }
        item { Text("Distancia (km, opcional)", style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp)) }
        item { Field(km, "Déjalo vacío si no la conoces", singleLine = true) { km = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(6) } }
        item { Text("Nota privada", style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp)) }
        item { Field(note, "Opcional") { note = it } }
        item {
            PillButton("Guardar", color = C.Green, icon = Icons.Rounded.Check, enabled = valid, modifier = Modifier.fillMaxWidth()) {
                scope.launch {
                    val start = day.atTime(hour, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    g.runs.addManual(sp, start, mins!! * 60_000L, dist?.let { it * 1000 }, note)
                    nav.popBackStack()
                }
            }
        }
    }
}
