package app.fuckrun.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Looper
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.Music
import app.fuckrun.data.MusicProvider
import app.fuckrun.data.PlanState
import app.fuckrun.data.db.RunKind
import app.fuckrun.data.state
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.Sport
import app.fuckrun.tracking.*
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Preparación. A la vista: deporte, «Música», estado del GPS y «Empezar». El origen y la cuenta atrás van en
 * «Más opciones». Todo el estado es guardable: al volver del proveedor musical aparece la misma preparación.
 *
 * Arranque seguro (corrección del cierre al empezar):
 *  - Antes de arrancar y al acabar la cuenta atrás se comprueban permiso, ubicación del sistema y visibilidad.
 *  - La cuenta atrás se detiene si la app pasa a segundo plano (p. ej. al abrir la música): Android no permite
 *    iniciar un servicio de ubicación desde segundo plano y antes eso cerraba la app.
 *  - El registro solo se abre cuando el servicio confirma el inicio (StartState.Started). Si falla, se muestra
 *    la acción correspondiente y no queda ninguna actividad vacía. Un doble toque abre una sola sesión.
 */
@SuppressLint("MissingPermission")
@Composable
fun PreRunScreen(nav: NavController, kind0: String, planned0: Long?, route0: String?, shared0: String?, sharedName0: String?) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val settings0 by g.profile.settings.collectAsStateWithLifecycle<AppSettings?>(null)
    val settings = settings0 ?: AppSettings()
    val planned by remember { g.routines.planned() }.collectAsStateWithLifecycle(emptyList())
    val favorites by remember { g.db.favorites().all() }.collectAsStateWithLifecycle(emptyList())
    val sharedList by remember { g.shared.mySessions() }.collectAsStateWithLifecycle(emptyList())
    val live by Tracking.live.collectAsStateWithLifecycle()
    val startState by Tracking.startState.collectAsStateWithLifecycle()

    var kind by rememberSaveable { mutableStateOf(kind0) }
    var plannedId by rememberSaveable { mutableStateOf(planned0) }
    var routeId by rememberSaveable { mutableStateOf(route0) }
    var sharedId by rememberSaveable { mutableStateOf(shared0) }
    var sharedName by rememberSaveable { mutableStateOf(sharedName0) }
    var sportId by rememberSaveable { mutableStateOf<String?>(null) }
    var countdownOn by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var optionsOpen by rememberSaveable { mutableStateOf(false) }
    var countdown by rememberSaveable { mutableStateOf<Int?>(null) }
    var requested by rememberSaveable { mutableStateOf(false) }
    var localFailure by remember { mutableStateOf<StartFailure?>(null) }

    // Deporte inicial: el del origen (rutina o encuentro) o el último deporte libre.
    LaunchedEffect(settings0, planned, sharedList) {
        if (sportId != null || settings0 == null) return@LaunchedEffect
        sportId = when (kind) {
            RunKind.ROUTINE -> planned.firstOrNull { it.id == plannedId }?.sport ?: if (planned.isEmpty() && plannedId != null) return@LaunchedEffect else settings.lastFreeSport.name
            RunKind.SHARED -> sharedList.firstOrNull { it.id == sharedId }?.sport ?: settings.lastFreeSport.name
            RunKind.ROUTE -> g.routes.byId(routeId)?.let { r -> val ok = routeSports(r)
                if (settings.lastFreeSport in ok) settings.lastFreeSport.name else ok.first().name } ?: settings.lastFreeSport.name
            else -> settings.lastFreeSport.name
        }
    }
    LaunchedEffect(settings0) { if (countdownOn == null && settings0 != null) countdownOn = settings.countdown }
    val sport = Sport.of(sportId ?: settings.lastFreeSport.name)

    val lm = remember { ctx.getSystemService(LocationManager::class.java) }
    var fine by remember { mutableStateOf(Tracking.hasLocationPermission(ctx)) }
    var coarse by remember { mutableStateOf(Tracking.hasCoarsePermission(ctx)) }
    var locOn by remember { mutableStateOf(LocationManagerCompat.isLocationEnabled(lm)) }
    var signal by remember { mutableStateOf(SignalQuality.NONE) }
    var accuracy by remember { mutableStateOf<Float?>(null) }
    var notifOk by remember { mutableStateOf(notificationsAllowed(ctx)) }
    var resumed by remember { mutableStateOf(true) }
    var askedFine by rememberSaveable { mutableStateOf(false) }

    fun refresh() {
        fine = Tracking.hasLocationPermission(ctx); coarse = Tracking.hasCoarsePermission(ctx)
        locOn = LocationManagerCompat.isLocationEnabled(lm); notifOk = notificationsAllowed(ctx)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh(); askedFine = true }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }
    fun appSettings() = runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))) }
    fun requestLocation() {
        // Si el sistema ya no muestra el diálogo (denegado dos veces), lo único útil es Ajustes.
        if (askedFine && !fine) appSettings()
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    // Recalcular al volver de Ajustes o del proveedor musical; pausar la cuenta atrás si la app deja de verse.
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> { refresh(); resumed = true }
                Lifecycle.Event.ON_PAUSE -> resumed = false
                else -> Unit
            }
        }
        lifecycle.addObserver(o); onDispose { lifecycle.removeObserver(o) }
    }
    LaunchedEffect(Unit) { Tracking.resetStart() }

    // Señal: SOLO mientras esta pantalla está abierta. Se detiene al salir.
    DisposableEffect(fine, locOn) {
        val l = object : LocationListener {
            override fun onLocationChanged(loc: android.location.Location) { accuracy = if (loc.hasAccuracy()) loc.accuracy else null; signal = signalFor(accuracy) }
            override fun onProviderEnabled(provider: String) { locOn = true }
            override fun onProviderDisabled(provider: String) { locOn = false; signal = SignalQuality.NONE }
            @Deprecated("Deprecated in API") override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
        }
        if (fine && locOn) runCatching { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, l, Looper.getMainLooper()) }
        onDispose { runCatching { lm.removeUpdates(l) } }
    }

    val blocker: StartFailure? = when { !coarse -> StartFailure.PERMISSION; !fine -> StartFailure.APPROXIMATE; !locOn -> StartFailure.GPS_OFF; else -> null }
    val failure: StartFailure? = localFailure ?: (startState as? StartState.Failed)?.reason?.takeIf { requested }
    val starting = startState is StartState.Starting

    fun begin() {
        refresh()
        val b = when { !Tracking.hasCoarsePermission(ctx) -> StartFailure.PERMISSION; !Tracking.hasLocationPermission(ctx) -> StartFailure.APPROXIMATE
            !LocationManagerCompat.isLocationEnabled(lm) -> StartFailure.GPS_OFF; else -> null }
        if (b != null) { localFailure = b; return }
        localFailure = null
        requested = true
        Tracking.start(ctx, sport, kind, plannedId, routeId, sharedId, sharedName)
    }
    fun onFailureAction(f: StartFailure) = when (f) {
        StartFailure.PERMISSION, StartFailure.APPROXIMATE -> requestLocation()
        StartFailure.GPS_OFF -> { runCatching { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }; Unit }
        StartFailure.NOT_ALLOWED, StartFailure.ERROR -> { localFailure = null; begin() }
    }

    // La cuenta atrás solo avanza con la app visible; al llegar a 0 se vuelve a comprobar todo antes de arrancar.
    LaunchedEffect(countdown, resumed) {
        val c = countdown ?: return@LaunchedEffect
        if (!resumed) return@LaunchedEffect
        if (c > 0) { delay(1000); countdown = c - 1 } else { countdown = null; begin() }
    }
    // Abrir el registro solo tras la confirmación de inicio.
    LaunchedEffect(startState, requested) {
        val st = startState
        if (requested && st is StartState.Started) {
            requested = false
            if (kind == RunKind.FREE) g.profile.update { it.copy(lastFreeSport = sport) }
            nav.navigate(Routes.ACTIVE) { popUpTo(Routes.HOME) }
        }
    }
    // Al limpiar un bloqueo (p. ej. tras conceder el permiso) desaparece el aviso.
    LaunchedEffect(blocker) { if (blocker == null && localFailure != null && localFailure != StartFailure.NOT_ALLOWED && localFailure != StartFailure.ERROR) localFailure = null }

    val plannedItem = planned.firstOrNull { it.id == plannedId }
    val route = g.routes.byId(routeId)
    val originLabel = when (kind) {
        RunKind.ROUTINE -> "Rutina: ${plannedItem?.name ?: ""}"
        RunKind.ROUTE -> "Ruta: ${route?.name ?: ""}"
        RunKind.SHARED -> "Encuentro: ${sharedName ?: ""}"
        else -> "Libre"
    }

    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Preparar actividad", style = T.ScreenTitle, modifier = Modifier.weight(1f))
                RoundIconButton(Icons.Rounded.Close, "Cerrar") { nav.popBackStack() }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (live != null) {
                    Notice("Ya tienes una actividad en curso.", icon = Icons.Rounded.Info)
                    PillButton("Volver a la actividad", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {
                        nav.navigate(Routes.ACTIVE) { popUpTo(Routes.HOME) }
                    }
                }
                SportSelector(sport, enabled = countdown == null && !starting) { s ->
                    sportId = s.name
                    if (kind == RunKind.FREE) scope.launch { g.profile.update { it.copy(lastFreeSport = s) } }
                }
                if (kind != RunKind.FREE) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 6.dp)) {
                    Icon(originIcon(kind), null, tint = C.TextSec, modifier = Modifier.size(18.dp))
                    Text("  $originLabel", style = T.Label)
                }
                if (route != null && sport !in routeSports(route)) Notice("Esta ruta no está verificada para ${sport.label.lowercase()}. Comprueba que está permitido antes de salir.",
                    color = C.Amber.copy(alpha = 0.18f), icon = Icons.Rounded.Warning)
                if (kind == RunKind.SHARED) Text("Tu registro queda en tu historial privado. No se comparte tu ubicación, tiempos ni recorrido.", style = T.Label,
                    modifier = Modifier.padding(horizontal = 6.dp))

                MusicRow(settings.music, onChoose = { p -> scope.launch { g.profile.update { it.copy(music = p) } } }, onOpen = { p -> openMusic(ctx, sheet, p) })

                GpsRow(blocker, signal, accuracy, highlight = failure != null && failure == blocker) { blocker?.let { onFailureAction(it) } }
                if (Build.VERSION.SDK_INT >= 33 && !notifOk) {
                    RowAction(Icons.Rounded.NotificationsOff, "Notificaciones desactivadas", "Sin ellas no verás el aviso de actividad, pero el registro funciona.", "Permitir") {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
                failure?.takeIf { it != blocker }?.let { f ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Red.copy(alpha = 0.12f)).padding(14.dp)
                        .semantics { liveRegion = LiveRegionMode.Polite }) {
                        Text(f.message, style = T.Body)
                        Spacer(Modifier.height(10.dp))
                        PillButton(f.action, color = C.Text, textColor = C.Bg) { onFailureAction(f) }
                    }
                }

                // Opciones secundarias: origen y cuenta atrás.
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).liquid(RoundedCornerShape(16.dp)) { optionsOpen = !optionsOpen }.padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Más opciones", style = T.Body.copy(color = C.TextSec), modifier = Modifier.weight(1f))
                    Icon(if (optionsOpen) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null, tint = C.TextSec)
                }
                if (optionsOpen) FCard {
                    ListRow("Origen", originLabel, leading = originIcon(kind)) {
                        val today = LocalDate.now()
                        sheet.show {
                            MenuTitle("Origen de la sesión")
                            MenuRow("Libre", Icons.Rounded.Bolt, selected = kind == RunKind.FREE) {
                                kind = RunKind.FREE; plannedId = null; routeId = null; sharedId = null; sportId = settings.lastFreeSport.name; sheet.hide()
                            }
                            planned.filter { it.state() == PlanState.PENDING && it.epochDay <= today.plusDays(2).toEpochDay() ||
                                it.state() == PlanState.MISSED && it.epochDay >= today.minusDays(2).toEpochDay() }.forEach { p ->
                                MenuRow("Rutina: ${p.name}", Icons.Rounded.CalendarMonth, subtitle = Fmt.dateLong(LocalDate.ofEpochDay(p.epochDay)),
                                    selected = kind == RunKind.ROUTINE && plannedId == p.id) {
                                    kind = RunKind.ROUTINE; plannedId = p.id; routeId = p.routeId; sharedId = null; sportId = p.sport; sheet.hide()
                                }
                            }
                            favorites.mapNotNull { g.routes.byId(it.routeId) }.forEach { r ->
                                MenuRow("Ruta: ${r.name}", Icons.Rounded.Route, subtitle = "${Fmt.km(r.distanceM, 1)} km", selected = kind == RunKind.ROUTE && routeId == r.id) {
                                    kind = RunKind.ROUTE; routeId = r.id; plannedId = null; sharedId = null; sheet.hide()
                                }
                            }
                            sharedList.filter { it.startAt > System.currentTimeMillis() - 6 * 3600_000 }.forEach { s ->
                                MenuRow("Encuentro: ${s.name}", Icons.Rounded.Groups, subtitle = s.meetingLabel, selected = kind == RunKind.SHARED && sharedId == s.id) {
                                    kind = RunKind.SHARED; sharedId = s.id; sharedName = s.name; plannedId = null; routeId = s.routeId; sportId = s.sport; sheet.hide()
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Timer, null, tint = C.Text); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) { Text("Cuenta atrás de 3 s", style = T.BodyStrong); Text("Opcional", style = T.Label) }
                        Switch(countdownOn == true, { countdownOn = it }, colors = SwitchDefaults.colors(checkedTrackColor = C.Green, checkedThumbColor = C.OnColor))
                    }
                }
                Text("La ubicación se usa solo mientras registras, para medir y dibujar tu recorrido. Se guarda en este móvil y, si tienes cuenta, en tu copia privada.",
                    style = T.Label, modifier = Modifier.padding(horizontal = 6.dp))
                Spacer(Modifier.height(8.dp))
            }
            Box(Modifier.fillMaxWidth().padding(16.dp)) {
                PillButton(if (starting) "Iniciando…" else "Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true,
                    enabled = live == null && !starting && countdown == null, modifier = Modifier.fillMaxWidth()) {
                    if (blocker != null) { localFailure = blocker; onFailureAction(blocker) }
                    else { localFailure = null; countdown = if (countdownOn == true) 3 else 0 }
                }
            }
        }
        countdown?.takeIf { it > 0 }?.let { c ->
            Box(Modifier.fillMaxSize().background(C.Bg.copy(alpha = 0.94f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    SportBadge(sport, 64.dp)
                    Spacer(Modifier.height(10.dp))
                    Text("$c", style = T.RunMetric.copy(fontSize = 128.sp), modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive })
                    if (!resumed) Text("En pausa hasta que vuelvas a Athlete Club", style = T.Label)
                    Spacer(Modifier.height(20.dp))
                    PillButton("Cancelar", color = C.Control, textColor = C.Text) { countdown = null }
                }
            }
        }
    }
}

private fun notificationsAllowed(ctx: android.content.Context) = Build.VERSION.SDK_INT < 33 ||
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED

fun originIcon(kind: String): ImageVector = when (kind) {
    RunKind.ROUTINE -> Icons.Rounded.CalendarMonth; RunKind.ROUTE -> Icons.Rounded.Route; RunKind.SHARED -> Icons.Rounded.Groups; else -> Icons.Rounded.Bolt
}

/** Deportes verificados para una ruta. Sin dato, solo a pie: nunca se supone que admite bicicleta. */
fun routeSports(r: app.fuckrun.data.VerifiedRoute): Set<Sport> =
    r.sports?.mapNotNull { id -> Sport.entries.firstOrNull { it.name == id } }?.toSet() ?: setOf(Sport.RUN, Sport.WALK, Sport.HIKE)

/** Fila «Música»: nota musical y proveedor favorito o «Elegir». El menú se despliega desde la fila. */
@Composable
fun MusicRow(provider: MusicProvider?, onChoose: (MusicProvider) -> Unit, onOpen: (MusicProvider) -> Unit) {
    val sheet = LocalSheet.current
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).liquid(RoundedCornerShape(20.dp), C.Card, role = Role.DropdownList, onClickLabel = "Elegir música") {
        sheet.show {
            MenuTitle("Música")
            if (provider != null && provider != MusicProvider.NONE) {
                Music.info(provider)?.let { MenuRow(it.openLabel, Icons.Rounded.OpenInNew, C.Green) { sheet.hide(); onOpen(provider) } }
            }
            MusicProvider.entries.forEach { p ->
                MenuRow(p.label, if (p == MusicProvider.NONE) Icons.Rounded.MusicOff else Icons.Rounded.MusicNote, selected = p == provider) { sheet.hide(); onChoose(p) }
            }
        }
    }.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(C.Control), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MusicNote, null, tint = C.Text) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Música", style = T.BodyStrong)
            Text(provider?.label ?: "Elegir", style = T.Label)
        }
        val info = provider?.let { Music.info(it) }
        if (provider != null && info != null) Text(info.openLabel, style = T.Label.copy(color = C.Text),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control) { onOpen(provider) }.padding(horizontal = 12.dp, vertical = 14.dp))
        else Icon(Icons.Rounded.ExpandMore, null, tint = C.TextSec)
    }
}

/** Abre el proveedor. Si no está instalado: web, instalar o elegir otro. «Empezar» sigue disponible siempre. */
fun openMusic(ctx: android.content.Context, sheet: SheetController, p: MusicProvider) {
    when (Music.open(ctx, p)) {
        Music.Result.Opened -> Unit
        else -> sheet.dialog {
            Text("${p.label} no está disponible", style = T.Section)
            Spacer(Modifier.height(8.dp))
            Text("No encontramos la app en este móvil. Puedes usar su web, instalarla o elegir otra opción. Puedes empezar igualmente.", style = T.Body.copy(color = C.TextSec))
            Spacer(Modifier.height(16.dp))
            PillButton("Abrir en la web", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide(); Music.openWeb(ctx, p) }
            Spacer(Modifier.height(8.dp))
            PillButton("Instalar ${p.label}", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide(); Music.openStore(ctx, p) }
            Spacer(Modifier.height(8.dp))
            PillButton("Seguir sin abrirla", color = C.Text, textColor = C.Bg, modifier = Modifier.fillMaxWidth()) { sheet.hide() }
        }
    }
}

@Composable
fun GpsRow(blocker: StartFailure?, signal: SignalQuality, accuracy: Float?, highlight: Boolean, onAction: () -> Unit) {
    val (title, sub, color) = when {
        blocker == StartFailure.PERMISSION -> Triple("Ubicación no permitida", "Permite la ubicación para dibujar tu recorrido.", C.Red)
        blocker == StartFailure.APPROXIMATE -> Triple("Ubicación aproximada", "Activa la ubicación precisa para medir bien la distancia.", C.Red)
        blocker == StartFailure.GPS_OFF -> Triple("Ubicación desactivada", "Actívala en los ajustes del móvil.", C.Red)
        signal == SignalQuality.NONE -> Triple("Buscando señal", "Al aire libre suele tardar menos. Puedes empezar: el recorrido aparecerá con la señal.", C.Amber)
        signal == SignalQuality.WEAK -> Triple("Señal débil", accuracy?.let { "Precisión ±${it.toInt()} m" } ?: "", C.Amber)
        else -> Triple("GPS listo", accuracy?.let { "Precisión ±${it.toInt()} m" } ?: "", C.Green)
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(if (highlight) C.Red.copy(alpha = 0.12f) else C.Card)
        .padding(horizontal = 14.dp, vertical = 10.dp).semantics { liveRegion = LiveRegionMode.Polite }, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(if (blocker != null) Icons.Rounded.LocationOff else Icons.Rounded.GpsFixed, null, tint = color)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            if (sub.isNotBlank()) Text(sub, style = T.Label)
        }
        if (blocker != null) Text(blocker.action, style = T.Label.copy(color = C.Bg),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Text, onClick = onAction).padding(horizontal = 12.dp, vertical = 14.dp))
    }
}

@Composable
fun RowAction(icon: ImageVector, title: String, sub: String, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Card).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = C.TextSec); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, style = T.BodyStrong); Text(sub, style = T.Label) }
        Text(action, style = T.Label.copy(color = C.Text),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control, onClick = onAction).padding(horizontal = 12.dp, vertical = 14.dp))
    }
}
