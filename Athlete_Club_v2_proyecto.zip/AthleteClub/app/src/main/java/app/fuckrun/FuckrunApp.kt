package app.fuckrun

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.compose.runtime.mutableStateOf
import app.fuckrun.data.*
import app.fuckrun.data.account.AccountRepository
import app.fuckrun.data.account.FirebaseHolder
import app.fuckrun.data.account.SyncEngine
import app.fuckrun.data.account.accountUid
import app.fuckrun.data.db.AppDatabase
import app.fuckrun.data.shared.SharedSessionsRepository
import app.fuckrun.tracking.Tracking
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import org.osmdroid.config.Configuration

/**
 * Contenedor de dependencias de UN perfil local: invitado (accountUid = null) o una cuenta.
 * Cada perfil tiene su propia base de datos y sus propias preferencias, así que cambiar de cuenta aísla la copia local.
 */
class AppGraph(app: Application, val accountUid: String?, val shared: SharedSessionsRepository, sync: () -> Unit) {
    val db = AppDatabase.build(app, accountUid)
    val clock = DeviceClock(app)
    val runs = RunRepository(db, clock)
    val routines = RoutineRepository(db)
    val profile = ProfileStore(app, accountUid)
    val municipalities by lazy { MunicipalityIndex(app) }
    val routes by lazy { RouteCatalog(app) }

    init {
        if (accountUid != null) { runs.onChange = sync; routines.onChange = sync; profile.onChange = sync }
    }
}

class FuckrunApp : Application() {
    /** Observable: al cambiar de perfil, la interfaz se recompone con los datos del nuevo perfil. */
    private val graphState = mutableStateOf<AppGraph?>(null)
    var graph: AppGraph
        get() = graphState.value ?: throw IllegalStateException("Athlete Club todavía no se ha inicializado")
        private set(v) { graphState.value = v }
    lateinit var firebase: FirebaseHolder private set
    lateinit var account: AccountRepository private set
    lateinit var device: DeviceStore private set
    lateinit var sync: SyncEngine private set
    private lateinit var shared: SharedSessionsRepository
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        instance = this
        super.onCreate()
        firebase = FirebaseHolder(this)
        account = AccountRepository(firebase)
        device = DeviceStore(this)
        shared = SharedSessionsRepository(this, firebase)
        sync = SyncEngine(firebase, device) { graph }
        graph = AppGraph(this, account.currentAccountUid(), shared) { sync.request() }

        Configuration.getInstance().apply {
            load(this@FuckrunApp, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = "AthleteClub/${BuildConfig.VERSION_NAME} (${BuildConfig.APPLICATION_ID})"
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SESSION, "Actividad en curso", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Aviso visible de Athlete Club mientras registras una actividad"
        })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Avisos durante la actividad", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pérdida de señal, GPS desactivado o batería baja durante una actividad"
        })
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Recordatorios de rutina", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_CLUB, "Cambios en encuentros del club", NotificationManager.IMPORTANCE_DEFAULT))

        // Cambio de cuenta: nunca con una actividad en marcha (se espera a que termine).
        appScope.launch {
            combine(account.state.map { it.accountUid }, Tracking.live.map { it == null }) { uid, idle -> uid to idle }
                .distinctUntilChanged()
                .collect { (uid, idle) -> if (idle) switchProfile(uid) }
        }
        sync.start(shared.online)
    }

    private fun switchProfile(uid: String?) {
        if (graph.accountUid == uid) return
        val old = graph
        graph = AppGraph(this, uid, shared) { sync.request() }
        // La interfaz se vuelve a crear con el nuevo grafo; la base anterior se cierra cuando ya nadie la usa.
        appScope.launch { delay(15_000); runCatching { old.db.close() } }
        sync.request()
    }

    /** Borra la copia local de una cuenta en este dispositivo (tras eliminar la cuenta). */
    fun deleteLocalProfile(uid: String) { deleteDatabase(AppDatabase.nameFor(uid)) }

    companion object {
        const val CH_SESSION = "session"
        const val CH_ALERTS = "session_alerts"
        const val CH_REMINDERS = "reminders"
        const val CH_CLUB = "club"
        lateinit var instance: FuckrunApp
            private set
        val graph get() = instance.graph
    }
}
