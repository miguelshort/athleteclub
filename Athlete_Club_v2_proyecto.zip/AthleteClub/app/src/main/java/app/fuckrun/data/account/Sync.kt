package app.fuckrun.data.account

import androidx.room.withTransaction
import app.fuckrun.AppGraph
import app.fuckrun.data.AppJson
import app.fuckrun.data.AppSettings
import app.fuckrun.data.DeviceStore
import app.fuckrun.data.db.*
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.encodeToString

/**
 * Estado visible en Perfil. «Sincronizado» SOLO cuando el servidor ha confirmado todo, incluidos los tramos de la ruta.
 */
sealed interface SyncStatus {
    data object NotConfigured : SyncStatus
    data object Guest : SyncStatus
    data class Synced(val at: Long) : SyncStatus
    data class Pending(val lastAt: Long?) : SyncStatus
    data class Running(val lastAt: Long?) : SyncStatus
    data class Error(val message: String, val lastAt: Long?) : SyncStatus
}

/**
 * Copia privada en la cuenta. Modelo Firestore (reglas en firebase/firestore.rules):
 *
 *   private/{uid}/activities/{syncId}             resumen, deporte, nota, eventos de pausa; complete=true al final
 *   private/{uid}/activities/{syncId}/chunks/{i}  puntos GPS por tramos de [CHUNK] puntos
 *   private/{uid}/routines/{syncId}               rutina
 *   private/{uid}/planned/{syncId}                sesión planificada (vínculo con rutina y actividad por syncId)
 *   private/{uid}/favorites/{routeId}             ruta favorita
 *   private/{uid}/tombstones/{key}                borrados (impiden recuperar lo eliminado)
 *   private/{uid}/meta/settings                   formulario y preferencias (JSON)
 *
 * Solo el propio usuario puede leer o escribir private/{uid}. Club vive aparte (sessions/, invites/).
 * Idempotente: los documentos usan identificadores estables, así que un reintento nunca duplica una sesión.
 * Las coordenadas nunca se escriben en registros de diagnóstico.
 */
class SyncEngine(private val fb: FirebaseHolder, private val device: DeviceStore, private val graph: () -> AppGraph) {
    companion object { const val CHUNK = 400 }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val requests = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    private val _status = MutableStateFlow<SyncStatus>(SyncStatus.Guest)
    val status: StateFlow<SyncStatus> = _status.asStateFlow()
    private val mutex = Mutex()

    fun request() { requests.tryEmit(Unit) }

    fun start(online: Flow<Boolean>) {
        scope.launch { requests.conflate().collect { delay(1200); runCatching { runOnce() } } }
        scope.launch { online.collect { if (it) request() else refreshOffline() } }
        request()
    }

    private suspend fun refreshOffline() {
        val uid = graph().accountUid ?: return
        _status.value = SyncStatus.Pending(device.lastSync(uid).first())
    }

    /** Una pasada completa: subir pendientes y borrados, después traer lo que falte. */
    suspend fun runOnce() { mutex.withLock { pass() } }

    private suspend fun pass() {
        val g = graph()
        val uid = g.accountUid
        if (uid == null) { _status.value = if (fb.configured) SyncStatus.Guest else SyncStatus.NotConfigured; return }
        val f = fb.fs
        if (f == null) { _status.value = SyncStatus.NotConfigured; return }
        val last = device.lastSync(uid).first()
        if (!fb.online()) { _status.value = SyncStatus.Pending(last); return }
        _status.value = SyncStatus.Running(last)
        try {
            withTimeout(180_000) {
                val base = f.collection("private").document(uid)
                push(g, base)
                pull(g, base)
                push(g, base)   // lo que haya cambiado al combinar (p. ej. vínculos)
            }
            val pending = g.db.runs().pendingCount().first() + g.db.routines().pendingCount().first() +
                g.db.favorites().pendingCount().first() + g.db.tombstones().pendingCount().first()
            if (graph() !== g) return
            if (pending == 0) {
                val now = System.currentTimeMillis()
                device.setLastSync(uid, now)
                _status.value = SyncStatus.Synced(now)
            } else {
                _status.value = SyncStatus.Pending(last)
            }
        } catch (e: TimeoutCancellationException) {
            _status.value = SyncStatus.Error("El servidor tarda demasiado", last)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (graph() === g) {
                _status.value = SyncStatus.Error(if (fb.online()) "No se ha podido completar la copia" else "Sin conexión", last)
            }
        }
    }

    // ---------- Subida ----------

    private suspend fun push(g: AppGraph, base: DocumentReference) {
        val db = g.db
        val now = System.currentTimeMillis()

        // 1) Borrados primero: así una restauración posterior nunca los recupera.
        for (t in db.tombstones().all().filter { it.syncedAt == 0L }) {
            base.collection("tombstones").document(safeId(t.key)).set(mapOf("kind" to t.kind, "deletedAt" to t.deletedAt)).await()
            when (t.kind) {
                "RUN" -> deleteActivity(base, t.key)
                "ROUTINE" -> base.collection("routines").document(t.key).delete().await()
                "PLANNED" -> base.collection("planned").document(t.key).delete().await()
                "FAVORITE" -> base.collection("favorites").document(safeId(t.key.removePrefix("fav:"))).delete().await()
            }
            db.tombstones().markSynced(t.key, now)
        }

        // 2) Actividades: primero los tramos, después el documento con complete=true.
        val runs = db.runs()
        for (r in runs.finishedOnce().filter { it.syncedAt < it.updatedAt }) {
            val pts = runs.points(r.id)
            val evs = runs.events(r.id)
            val chunks = pts.chunked(CHUNK)
            val doc = base.collection("activities").document(r.syncId)
            chunks.forEachIndexed { i, c ->
                doc.collection("chunks").document(i.toString()).set(mapOf("i" to i, "p" to c.map { pointMap(it) })).await()
            }
            val plannedSync = r.plannedSessionId?.let { db.routines().planned(it)?.syncId }
            doc.set(runMap(r, plannedSync, chunks.size, pts.size, evs)).await()
            runs.markSynced(r.id, r.updatedAt)
        }

        // 3) Rutinas y sesiones planificadas.
        val rdao = db.routines()
        val routines = rdao.routinesOnce()
        for (r in routines.filter { it.syncedAt < it.updatedAt }) {
            base.collection("routines").document(r.syncId).set(mapOf(
                "name" to r.name, "kind" to r.kind, "startEpochDay" to r.startEpochDay, "endEpochDay" to r.endEpochDay,
                "templateId" to r.templateId, "createdAt" to r.createdAt, "updatedAt" to r.updatedAt,
            )).await()
            rdao.markRoutineSynced(r.id, r.updatedAt)
        }
        val routineSync = routines.associate { it.id to it.syncId }
        for (p in rdao.allPlannedOnce().filter { it.syncedAt < it.updatedAt }) {
            val linked = p.linkedRunId?.let { runs.get(it)?.takeIf { r -> r.status == RunStatus.FINISHED }?.syncId }
            base.collection("planned").document(p.syncId).set(mapOf(
                "routineSyncId" to routineSync[p.routineId], "name" to p.name, "epochDay" to p.epochDay, "type" to p.type,
                "targetMinutes" to p.targetMinutes, "targetKm" to p.targetKm, "intensity" to p.intensity, "structure" to p.structure,
                "routeId" to p.routeId, "reminderMinuteOfDay" to p.reminderMinuteOfDay, "skipped" to p.skipped,
                "linkedRunSyncId" to linked, "sport" to p.sport, "updatedAt" to p.updatedAt,
            )).await()
            rdao.markPlannedSynced(p.id, p.updatedAt)
        }

        // 4) Favoritos.
        for (fav in db.favorites().allOnce().filter { it.syncedAt == 0L }) {
            base.collection("favorites").document(safeId(fav.routeId)).set(mapOf("routeId" to fav.routeId, "addedAt" to fav.addedAt)).await()
            db.favorites().markSynced(fav.routeId, now)
        }

        // 5) Formulario y preferencias.
        val s = g.profile.current()
        if (s.updatedAt > device.settingsSyncedAt(g.accountUid!!)) {
            base.collection("meta").document("settings").set(mapOf("json" to AppJson.encodeToString(s), "updatedAt" to s.updatedAt)).await()
            device.setSettingsSyncedAt(g.accountUid!!, s.updatedAt)
        }
    }

    private suspend fun deleteActivity(base: DocumentReference, syncId: String) {
        val doc = base.collection("activities").document(syncId)
        val chunks = doc.collection("chunks").get(Source.SERVER).await()
        for (c in chunks.documents) c.reference.delete().await()
        doc.delete().await()
    }

    // ---------- Bajada y restauración ----------

    private suspend fun pull(g: AppGraph, base: DocumentReference) {
        val db = g.db
        val now = System.currentTimeMillis()
        val remoteTombs = base.collection("tombstones").get(Source.SERVER).await().documents.associate { it.id to (it.getString("kind") ?: "") }
        val localTombs = db.tombstones().keys().toSet()

        // Borrados hechos en otro dispositivo.
        for ((k, kind) in remoteTombs) {
            if (k in localTombs) continue
            when (kind) {
                "RUN" -> db.runs().bySyncId(k)?.let { db.routines().unlinkRun(it.id); db.runs().delete(it.id) }
                "ROUTINE" -> db.routines().routineBySyncId(k)?.let { db.routines().delete(it.id) }
                "PLANNED" -> db.routines().plannedBySyncId(k)?.let { db.routines().deletePlanned(it.id) }
                "FAVORITE" -> db.favorites().remove(k.removePrefix("fav:"))
            }
            db.tombstones().put(TombstoneEntity(k, kind, now, syncedAt = now))
        }
        val tombs = localTombs + remoteTombs.keys

        // Actividades.
        val acts = base.collection("activities").get(Source.SERVER).await()
        for (d in acts.documents) {
            val sid = d.id
            if (sid in tombs || d.getBoolean("complete") != true) continue
            val rUpdated = d.getLong("updatedAt") ?: 0L
            val local = db.runs().bySyncId(sid)
            if (local == null) restoreActivity(g, d, rUpdated)
            else if (rUpdated > local.updatedAt) {
                db.runs().update(local.copy(note = d.getString("note") ?: local.note, sport = d.getString("sport") ?: local.sport,
                    updatedAt = rUpdated, syncedAt = rUpdated))
            }
        }

        // Rutinas.
        val rdao = db.routines()
        for (d in base.collection("routines").get(Source.SERVER).await().documents) {
            if (d.id in tombs) continue
            val upd = d.getLong("updatedAt") ?: 0L
            val local = rdao.routineBySyncId(d.id)
            val e = RoutineEntity(id = local?.id ?: 0, name = d.getString("name") ?: "Rutina", kind = d.getString("kind") ?: "CUSTOM",
                startEpochDay = d.getLong("startEpochDay") ?: 0, endEpochDay = d.getLong("endEpochDay") ?: 0, templateId = d.getString("templateId"),
                createdAt = d.getLong("createdAt") ?: upd, syncId = d.id, updatedAt = upd, syncedAt = upd)
            if (local == null) rdao.insert(e) else if (upd > local.updatedAt) rdao.update(e)
        }

        // Sesiones planificadas (necesitan la rutina; el vínculo con la actividad se resuelve por syncId).
        for (d in base.collection("planned").get(Source.SERVER).await().documents) {
            if (d.id in tombs) continue
            val routine = d.getString("routineSyncId")?.let { rdao.routineBySyncId(it) } ?: continue
            val upd = d.getLong("updatedAt") ?: 0L
            val local = rdao.plannedBySyncId(d.id)
            val linked = d.getString("linkedRunSyncId")?.let { db.runs().bySyncId(it)?.id }
            val e = PlannedSessionEntity(id = local?.id ?: 0, routineId = routine.id, name = d.getString("name") ?: "", epochDay = d.getLong("epochDay") ?: 0,
                type = d.getString("type") ?: "EASY", targetMinutes = d.getLong("targetMinutes")?.toInt(), targetKm = d.getDouble("targetKm"),
                intensity = d.getString("intensity") ?: "EASY", structure = d.getString("structure") ?: "", routeId = d.getString("routeId"),
                reminderMinuteOfDay = d.getLong("reminderMinuteOfDay")?.toInt(), skipped = d.getBoolean("skipped") == true,
                linkedRunId = linked, sport = d.getString("sport") ?: "RUN", syncId = d.id, updatedAt = upd, syncedAt = upd)
            if (local == null) rdao.insertPlanned(e) else if (upd > local.updatedAt) rdao.updatePlanned(e)
            if (linked != null) db.runs().get(linked)?.let { r -> if (r.plannedSessionId == null) db.runs().update(r.copy(plannedSessionId = rdao.plannedBySyncId(d.id)?.id)) }
        }

        // Favoritos.
        val localFavs = db.favorites().allOnce().map { it.routeId }.toSet()
        for (d in base.collection("favorites").get(Source.SERVER).await().documents) {
            val routeId = d.getString("routeId") ?: continue
            if (routeId in localFavs || "fav:$routeId" in tombs) continue
            db.favorites().add(FavoriteRouteEntity(routeId, d.getLong("addedAt") ?: now, syncedAt = now))
        }

        // Preferencias: gana la versión más reciente.
        val meta = base.collection("meta").document("settings").get(Source.SERVER).await()
        val remoteAt = meta.getLong("updatedAt") ?: 0L
        val local = g.profile.current()
        if (remoteAt > local.updatedAt) {
            meta.getString("json")?.let { j -> runCatching { AppJson.decodeFromString(AppSettings.serializer(), j) }.getOrNull() }?.let {
                g.profile.replaceFromRemote(it)
                device.setSettingsSyncedAt(g.accountUid!!, it.updatedAt)
            }
        }
    }

    /** Restaura una actividad completa (todos sus tramos) en una transacción y recalcula los totales desde los puntos. */
    private suspend fun restoreActivity(g: AppGraph, d: DocumentSnapshot, updated: Long) {
        val chunkCount = d.getLong("chunkCount")?.toInt() ?: 0
        val pointCount = d.getLong("pointCount")?.toInt() ?: 0
        val raw = mutableListOf<Map<*, *>>()
        for (i in 0 until chunkCount) {
            val c = d.reference.collection("chunks").document(i.toString()).get(Source.SERVER).await()
            (c.get("p") as? List<*>)?.forEach { (it as? Map<*, *>)?.let(raw::add) }
        }
        if (raw.size != pointCount) return   // incompleta: se reintentará en la próxima pasada
        val db = g.db
        val run = RunEntity(
            startedAtWall = d.getLong("startedAtWall") ?: return, endedAtWall = d.getLong("endedAtWall"),
            status = RunStatus.FINISHED, source = d.getString("source") ?: RunSource.GPS, kind = d.getString("kind") ?: RunKind.FREE,
            routeId = d.getString("routeId"), sharedSessionId = d.getString("sharedSessionId"), sharedSessionName = d.getString("sharedSessionName"),
            note = d.getString("note") ?: "", distanceM = d.getDouble("distanceM"), elapsedMs = d.getLong("elapsedMs") ?: 0,
            activeMs = d.getLong("activeMs") ?: 0, avgSpeedMps = d.getDouble("avgSpeedMps"), maxSpeedMps = d.getDouble("maxSpeedMps"),
            minMovingSpeedMps = d.getDouble("minMovingSpeedMps"), lostMs = d.getLong("lostMs") ?: 0, gapCount = d.getLong("gapCount")?.toInt() ?: 0,
            currentSegment = d.getLong("currentSegment")?.toInt() ?: 0, sport = d.getString("sport") ?: "RUN",
            syncId = d.id, updatedAt = updated, syncedAt = updated, elevationGainM = d.getDouble("elevationGainM"),
        )
        val events = (d.get("events") as? List<*>).orEmpty().mapNotNull { it as? Map<*, *> }
        val id = db.withTransaction {
            val id = db.runs().insert(run)
            db.runs().insertPoints(raw.map { m ->
                PointEntity(runId = id, segment = num(m["s"]).toInt(), wallMs = num(m["w"]).toLong(), monoMs = num(m["m"]).toLong(),
                    bootCount = num(m["b"]).toInt(), lat = num(m["a"]).toDouble(), lon = num(m["o"]).toDouble(),
                    accuracyM = num(m["c"]).toFloat(), altitudeM = (m["e"] as? Number)?.toDouble())
            })
            db.runs().insertEvents(events.map { m ->
                EventEntity(runId = id, type = m["t"] as? String ?: EventType.START, wallMs = num(m["w"]).toLong(), monoMs = num(m["m"]).toLong(),
                    bootCount = num(m["b"]).toInt(), detail = m["d"] as? String ?: "")
            })
            id
        }
        // Los totales se recalculan a partir de los registros restaurados, no se copian a ciegas.
        g.runs.recompute(id)
    }

    private fun num(v: Any?): Number = v as? Number ?: 0

    private fun pointMap(p: PointEntity) = buildMap<String, Any> {
        put("s", p.segment); put("w", p.wallMs); put("m", p.monoMs); put("b", p.bootCount)
        put("a", p.lat); put("o", p.lon); put("c", p.accuracyM.toDouble())
        p.altitudeM?.let { put("e", it) }
    }

    private fun runMap(r: RunEntity, plannedSync: String?, chunkCount: Int, pointCount: Int, evs: List<EventEntity>) = mapOf(
        "sport" to r.sport, "kind" to r.kind, "source" to r.source, "startedAtWall" to r.startedAtWall, "endedAtWall" to r.endedAtWall,
        "routeId" to r.routeId, "sharedSessionId" to r.sharedSessionId, "sharedSessionName" to r.sharedSessionName, "note" to r.note,
        "distanceM" to r.distanceM, "elapsedMs" to r.elapsedMs, "activeMs" to r.activeMs, "avgSpeedMps" to r.avgSpeedMps,
        "maxSpeedMps" to r.maxSpeedMps, "minMovingSpeedMps" to r.minMovingSpeedMps, "lostMs" to r.lostMs, "gapCount" to r.gapCount,
        "currentSegment" to r.currentSegment, "elevationGainM" to r.elevationGainM, "plannedSyncId" to plannedSync,
        "chunkCount" to chunkCount, "pointCount" to pointCount, "updatedAt" to r.updatedAt, "complete" to true,
        "events" to evs.map { mapOf("t" to it.type, "w" to it.wallMs, "m" to it.monoMs, "b" to it.bootCount, "d" to it.detail) },
    )

    private fun safeId(k: String) = k.replace('/', '_')

    /** Elimina toda la copia privada de la cuenta (antes de borrar el usuario). */
    suspend fun deleteRemote(f: FirebaseFirestore, uid: String) {
        val base = f.collection("private").document(uid)
        for (a in base.collection("activities").get(Source.SERVER).await().documents) deleteActivity(base, a.id)
        for (col in listOf("routines", "planned", "favorites", "tombstones", "meta")) {
            for (d in base.collection(col).get(Source.SERVER).await().documents) d.reference.delete().await()
        }
    }
}

/**
 * Lleva el historial del modo invitado a la cuenta, SOLO cuando el usuario lo confirma.
 * Copia actividades (con puntos y eventos), rutinas, sesiones y favoritos; después los quita del perfil invitado
 * para que no queden duplicados. Lo ya presente en la cuenta (mismo syncId) no se duplica.
 */
object GuestMerger {
    suspend fun guestCount(guest: AppDatabase) = guest.runs().finishedCount()

    suspend fun merge(guest: AppDatabase, target: AppDatabase): Int {
        val now = System.currentTimeMillis()
        var copied = 0
        val runMap = mutableMapOf<Long, Long>()
        val routineMap = mutableMapOf<Long, Long>()
        target.withTransaction {
            for (r in guest.runs().finishedOnce()) {
                val existing = target.runs().bySyncId(r.syncId)
                if (existing != null) { runMap[r.id] = existing.id; continue }
                val id = target.runs().insert(r.copy(id = 0, plannedSessionId = null, updatedAt = now, syncedAt = 0))
                target.runs().insertPoints(guest.runs().points(r.id).map { it.copy(id = 0, runId = id) })
                target.runs().insertEvents(guest.runs().events(r.id).map { it.copy(id = 0, runId = id) })
                runMap[r.id] = id; copied++
            }
            for (rt in guest.routines().routinesOnce()) {
                val existing = target.routines().routineBySyncId(rt.syncId)
                routineMap[rt.id] = existing?.id ?: target.routines().insert(rt.copy(id = 0, updatedAt = now, syncedAt = 0))
            }
            for (p in guest.routines().allPlannedOnce()) {
                if (target.routines().plannedBySyncId(p.syncId) != null) continue
                val rid = routineMap[p.routineId] ?: continue
                val linked = p.linkedRunId?.let { runMap[it] }
                val newId = target.routines().insertPlanned(p.copy(id = 0, routineId = rid, linkedRunId = linked, updatedAt = now, syncedAt = 0))
                linked?.let { lid -> target.runs().get(lid)?.let { target.runs().update(it.copy(plannedSessionId = newId)) } }
            }
            for (f in guest.favorites().allOnce()) target.favorites().add(f.copy(syncedAt = 0))
        }
        // Quitar del invitado lo que ya está en la cuenta.
        guest.withTransaction {
            runMap.keys.forEach { guest.runs().delete(it) }
            routineMap.keys.forEach { guest.routines().delete(it) }
            guest.favorites().deleteAll()
        }
        return copied
    }
}
