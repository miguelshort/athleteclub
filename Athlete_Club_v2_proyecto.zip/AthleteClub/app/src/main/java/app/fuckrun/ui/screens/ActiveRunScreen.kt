package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.AppSettings
import app.fuckrun.data.LatLon
import app.fuckrun.data.PrimaryMetric
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Fmt
import app.fuckrun.domain.NO_DATA
import app.fuckrun.domain.Sport
import app.fuckrun.domain.metrics.RunMetrics
import app.fuckrun.tracking.SignalQuality
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Registro. Primera vista: una cifra grande con su unidad, dos métricas secundarias, el mapa y los controles.
 * Por defecto: Correr → ritmo (min/km); Bicicleta → velocidad (km/h); Sendero → distancia (+ desnivel si es fiable);
 * Caminata → tiempo activo y distancia. La cifra principal se cambia tocándola; el resto, en «Ver métricas».
 * La barra inferior se oculta; «Minimizar» vuelve a Inicio sin detener el registro.
 */
@Composable
fun ActiveRunScreen(nav: NavController) {
    val ctx = LocalContext.current
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val live by Tracking.live.collectAsStateWithLifecycle()
    val settings by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    var locked by remember { mutableStateOf(false) }
    fun minimize() { if (!nav.popBackStack(Routes.HOME, false)) nav.navigate(Routes.HOME) }

    BackHandler { minimize() }   // minimizar nunca detiene la grabación

    var waited by remember { mutableIntStateOf(0) }
    LaunchedEffect(live == null) { while (live == null && waited < 8) { delay(1000); waited++ } }
    val l = live
    if (l == null) {
        Box(Modifier.fillMaxSize().background(C.Bg), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (waited < 8) "Iniciando registro…" else "No hay ninguna actividad en curso", style = T.Section)
                if (waited >= 8) { Spacer(Modifier.height(12.dp)); PillButton("Volver a Inicio", color = C.Control, textColor = C.Text) { minimize() } }
            }
        }
        return
    }
    val s = l.stats
    val sport = l.sport
    val paused = l.status == RunStatus.PAUSED
    val primary = settings.metricFor(sport).takeIf { it in PrimaryMetric.optionsFor(sport) } ?: PrimaryMetric.defaultFor(sport)
    val secondary = secondaryFor(sport, primary)

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        // Minimizar, estado y señal
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control, enabled = !locked, onClickLabel = "Minimizar") { minimize() }
                .padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = C.Text); Text(" Minimizar", style = T.BodyStrong)
            }
            Spacer(Modifier.weight(1f))
            StatusPill(if (paused) "En pausa" else "Grabando", if (paused) Icons.Rounded.Pause else Icons.Rounded.FiberManualRecord, if (paused) C.Red else C.Green)
            Spacer(Modifier.width(6.dp))
            val searching = l.waitingFirstFix || l.signal == SignalQuality.NONE
            StatusPill(if (searching) "Buscando señal" else l.signal.label, if (searching) Icons.Rounded.GpsNotFixed else Icons.Rounded.GpsFixed,
                if (searching || l.signal == SignalQuality.WEAK) C.Amber else C.TextSec)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SportBadge(sport, 36.dp); Text("  ${sport.label} · ${l.kindLabel}", style = T.Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            l.warnings.forEach { Notice(it.text, color = C.Red.copy(alpha = 0.14f), icon = Icons.Rounded.Warning) }
            if ("metric" !in settings.hintsSeen) Hint("Toca la cifra grande para cambiarla. «Ver métricas» muestra todas.") {
                scope.launch { g.profile.update { it.copy(hintsSeen = it.hintsSeen + "metric") } }
            }

            // Cifra principal: toca para cambiarla (menú desplegado desde la propia cifra).
            val (pLabel, pValue, pUnit) = metric(primary, s)
            Column(Modifier.fillMaxWidth().liquid(RoundedCornerShape(28.dp), C.Card, enabled = !locked, role = Role.DropdownList, onClickLabel = "Cambiar cifra principal") {
                sheet.pick("Cifra principal", PrimaryMetric.optionsFor(sport), { it.label }, primary, icon = { metricIcon(it) }) { m ->
                    scope.launch { g.profile.update { it.copy(primaryMetricBySport = it.primaryMetricBySport + (sport to m)) } }
                }
            }.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pLabel, style = T.Label, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.UnfoldMore, null, tint = C.TextSec, modifier = Modifier.size(18.dp))
                }
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.semantics(mergeDescendants = true) {}) {
                    Text(pValue, style = T.RunMetric, maxLines = 1)
                    if (pUnit.isNotEmpty() && pValue != NO_DATA) Text(" $pUnit", style = T.Section.copy(color = C.TextSec), modifier = Modifier.padding(bottom = 12.dp))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                secondary.forEach { m ->
                    val (lab, v, u) = metric(m, s)
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(C.Surface).padding(14.dp)) {
                        Text(lab, style = T.Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(v, style = T.Number.copy(fontSize = 30.sp), maxLines = 1)
                            if (u.isNotEmpty() && v != NO_DATA) Text(" $u", style = T.Label, modifier = Modifier.padding(bottom = 5.dp))
                        }
                    }
                }
            }
            RunMap(s?.segments?.map { seg -> seg.map { LatLon(it.lat, it.lon) } } ?: emptyList(),
                Modifier.fillMaxWidth().height(220.dp), follow = true, interactive = !locked)
            Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).liquid(RoundedCornerShape(50), C.Control, enabled = !locked) {
                sheet.show { AllMetrics(s, sport) }
            }.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(Icons.Rounded.GridView, null, tint = C.Text); Text("  Ver métricas", style = T.BodyStrong)
            }
            Spacer(Modifier.height(4.dp))
        }
        // Controles grandes. Verde = Reanudar, rojo = Pausar, azul = Terminar, en cualquier deporte.
        Box(Modifier.fillMaxWidth().padding(16.dp)) {
            if (locked) UnlockBar { locked = false }
            else Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundIconButton(Icons.Rounded.Lock, "Bloquear controles", Modifier.size(64.dp)) { locked = true }
                if (paused) PillButton("Reanudar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.weight(1f)) { Tracking.resume(ctx) }
                else PillButton("Pausar", color = C.Red, icon = Icons.Rounded.Pause, big = true, modifier = Modifier.weight(1f)) { Tracking.pause(ctx) }
                PillButton("Terminar", color = C.Blue, icon = Icons.Rounded.Stop, big = true, modifier = Modifier.weight(1f)) {
                    sheet.confirm("¿Terminar la actividad?", "Se detendrá el registro y la ubicación. Después podrás guardarla o descartarla.", "Terminar", C.Blue, Icons.Rounded.Stop) {
                        Tracking.stop(ctx)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size(14.dp)); Text(" $text", style = T.Label.copy(color = C.Text), maxLines = 1)
    }
}

fun metricIcon(m: PrimaryMetric) = when (m) {
    PrimaryMetric.TIME -> Icons.Rounded.Timer; PrimaryMetric.DISTANCE -> Icons.Rounded.Straighten; PrimaryMetric.PACE -> Icons.Rounded.Speed
    PrimaryMetric.SPEED -> Icons.Rounded.Speed; PrimaryMetric.ELEVATION -> Icons.Rounded.Terrain
}

private fun secondaryFor(sport: Sport, primary: PrimaryMetric): List<PrimaryMetric> {
    val pref = when (sport) {
        Sport.RUN -> listOf(PrimaryMetric.TIME, PrimaryMetric.DISTANCE, PrimaryMetric.PACE)
        Sport.BIKE -> listOf(PrimaryMetric.DISTANCE, PrimaryMetric.TIME, PrimaryMetric.SPEED)
        Sport.HIKE -> listOf(PrimaryMetric.ELEVATION, PrimaryMetric.TIME, PrimaryMetric.DISTANCE)
        Sport.WALK -> listOf(PrimaryMetric.DISTANCE, PrimaryMetric.PACE, PrimaryMetric.TIME)
    }
    return pref.filter { it != primary }.take(2)
}

fun metric(m: PrimaryMetric, s: RunMetrics.Stats?): Triple<String, String, String> = when (m) {
    PrimaryMetric.TIME -> Triple("Tiempo activo", Fmt.duration(s?.activeMs), "")
    PrimaryMetric.DISTANCE -> Triple("Distancia", Fmt.km(s?.let { st -> st.distanceM.takeIf { st.acceptedPoints >= 2 } }), "km")
    PrimaryMetric.PACE -> Triple("Ritmo actual", Fmt.pace(s?.currentPaceSecPerKm), "min/km")
    PrimaryMetric.SPEED -> Triple("Velocidad actual", Fmt.kmh(s?.currentSpeedMps), "km/h")
    PrimaryMetric.ELEVATION -> Triple("Desnivel positivo", s?.elevationGainM?.let { "%.0f".format(it) } ?: NO_DATA, "m")
}

/** Todas las métricas, a un toque desde «Ver métricas». */
@Composable
private fun AllMetrics(s: RunMetrics.Stats?, sport: Sport) {
    MenuTitle("Métricas · ${sport.label}")
    val items = listOf(
        Triple("Tiempo total", Fmt.duration(s?.elapsedMs), ""),
        Triple("Tiempo activo", Fmt.duration(s?.activeMs), ""),
        Triple("Distancia", Fmt.km(s?.let { st -> st.distanceM.takeIf { st.acceptedPoints >= 2 } }), "km"),
        Triple("Velocidad actual", Fmt.kmh(s?.currentSpeedMps), "km/h"),
        Triple("Velocidad media", Fmt.kmh(s?.avgSpeedMps), "km/h"),
        Triple("Velocidad máxima", Fmt.kmh(s?.maxSpeedMps), "km/h"),
        Triple("Mínima en movimiento", Fmt.kmh(s?.minMovingSpeedMps), "km/h"),
        Triple("Ritmo actual", Fmt.pace(s?.currentPaceSecPerKm), "min/km"),
        Triple("Ritmo medio", Fmt.pace(s?.avgPaceSecPerKm), "min/km"),
        Triple("Desnivel positivo", s?.elevationGainM?.let { "%.0f".format(it) } ?: NO_DATA, "m"),
    )
    Column(Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, value, unit) ->
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(C.Surface.copy(alpha = 0.7f)).padding(12.dp)) {
                        Text(label, style = T.Label, maxLines = 2)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(value, style = T.Number)
                            if (unit.isNotEmpty() && value != NO_DATA) Text(" $unit", style = T.Label, modifier = Modifier.padding(bottom = 3.dp))
                        }
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text("«$NO_DATA» = sin datos suficientes. La línea discontinua del mapa marca tramos sin señal. El tiempo total incluye las pausas; el activo, no.",
            style = T.Label)
    }
}

/** Desbloqueo visible: mantener pulsado 1,2 s con barra de progreso. */
@Composable
private fun UnlockBar(onUnlock: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(50)).background(C.Control)
        .semantics { contentDescription = "Mantén pulsado para desbloquear" }
        .pointerInput(Unit) {
            detectTapGestures(onPress = {
                val job = scope.launch { progress.animateTo(1f, tween(1200, easing = LinearEasing)); onUnlock() }
                tryAwaitRelease()
                if (progress.value < 1f) { job.cancel(); scope.launch { progress.animateTo(0f) } }
            })
        }, contentAlignment = Alignment.Center) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(progress.value).background(C.Text.copy(alpha = 0.18f)))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.LockOpen, null, tint = C.Text)
            Text("  Mantén pulsado para desbloquear", style = T.BodyStrong)
        }
    }
}
