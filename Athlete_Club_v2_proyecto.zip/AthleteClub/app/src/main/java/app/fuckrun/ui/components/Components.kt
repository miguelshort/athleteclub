@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.fuckrun.ui.components

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.paneTitle
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import dev.chrisbanes.haze.*

// ---------- Material de vidrio (Haze: RenderEffect en Android 12+, película translúcida en versiones anteriores) ----------

val LocalHaze = staticCompositionLocalOf { HazeState() }
/** Espacio que hay que reservar al final del contenido para que la cápsula no tape el último control. */
val LocalNavPadding = compositionLocalOf { 0.dp }
/** Ajuste del sistema «Quitar animaciones»: sin deformación ni rebotes. */
val LocalReduceMotion = staticCompositionLocalOf { false }

/**
 * Película translúcida adaptada al tema. Antes: tinte del 70 % (la superficie casi tapaba el contenido y no se percibía el
 * paso del color). Ahora: ~42 % en oscuro y ~55 % en claro, desenfoque de 28 dp, filo de luz de 1 dp y sombra corta.
 * Sin RenderEffect (Android < 12) se usa una película casi opaca, legible también sobre el mapa.
 */
fun glassStyle() = HazeStyle(
    backgroundColor = C.Bg,
    tints = listOf(HazeTint(C.GlassTint)),
    blurRadius = 28.dp,
    noiseFactor = 0f,
    fallbackTint = HazeTint(C.GlassFallback),
)

/** El desenfoque afecta solo a lo que hay DETRÁS (capa hazeSource); iconos y letras se dibujan encima, nítidos. */
fun Modifier.glass(shape: Shape, haze: HazeState) = this
    .clip(shape)
    .hazeEffect(state = haze, style = glassStyle())
    .border(1.dp, Brush.verticalGradient(listOf(C.EdgeTop, C.EdgeBottom)), shape)

/** Franja suave de salida de contenido bajo las cabeceras. Solo afecta al área desplazable. */
fun Modifier.topFade(height: Dp, enabled: Boolean) = if (!enabled) this else this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = height.toPx()
        drawRect(
            brush = Brush.verticalGradient(0f to Color.Transparent, 1f to Color.Black, startY = 0f, endY = h),
            size = Size(size.width, h), blendMode = BlendMode.DstIn,
        )
    }

// ---------- Respuesta táctil común ----------

private class AnchorBox { var rect: Rect = Rect.Zero; var lastClick = 0L }

/**
 * Componente táctil común (botones, pestañas, opciones de menú, selectores, interruptores y tarjetas).
 *  - Al apoyar el dedo la SUPERFICIE se ensancha ~4 % y se comprime ~2,5 % en altura; el reflejo se desplaza al contacto.
 *  - Mantener conserva la deformación y el tinte. Al soltar o cancelar vuelve con un muelle corto (~180 ms).
 *  - Solo se deforma el fondo dibujado aquí: el área de toque, las filas vecinas y el texto no cambian.
 *  - Un toque ejecuta una sola acción (se ignoran repeticiones en 350 ms); una pulsación larga no repite.
 *  - Registra la posición del control para que los menús se desplieguen desde él.
 */
fun Modifier.liquid(
    shape: Shape? = null,
    color: Color = Color.Transparent,
    enabled: Boolean = true,
    role: Role? = Role.Button,
    onClickLabel: String? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val sheet = LocalSheet.current
    val reduce = LocalReduceMotion.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val box = remember { AnchorBox() }
    var touch by remember { mutableStateOf(Offset.Unspecified) }
    val target = if (pressed && enabled) 1f else 0f
    val k by animateFloatAsState(
        target, label = "liquid",
        animationSpec = if (reduce) tween(0) else if (target == 1f) tween(90) else spring(dampingRatio = 0.62f, stiffness = 900f),
    )
    val click by rememberUpdatedState(onClick)
    val glow = C.Text
    this
        .onGloballyPositioned { box.rect = it.boundsInRoot() }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val e = awaitPointerEvent(PointerEventPass.Initial)
                    val ch = e.changes.firstOrNull()
                    if (ch != null && ch.pressed) touch = ch.position
                }
            }
        }
        .drawBehind {
            val d = if (reduce) 0f else k
            scale(1f + 0.04f * d, 1f - 0.025f * d) {
                val outline = (shape ?: RectangleShape).createOutline(size, layoutDirection, this)
                if (color.alpha > 0f) drawOutline(outline, color)
                if (k > 0.01f) {
                    val c = if (touch.isSpecified) touch else center
                    drawOutline(outline, Brush.radialGradient(listOf(glow.copy(alpha = 0.14f * k), Color.Transparent), center = c,
                        radius = size.maxDimension.coerceAtLeast(1f) * 0.9f))
                }
            }
        }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClickLabel = onClickLabel) {
            val now = SystemClock.uptimeMillis()
            if (now - box.lastClick < 350) return@clickable
            box.lastClick = now
            sheet.anchorAt(box.rect)
            click()
        }
}

/** Sustituto de clickable para superficies que ya pintan su fondo: misma respuesta táctil y anclaje de menús. */
fun Modifier.tap(enabled: Boolean = true, role: Role? = null, onClickLabel: String? = null, onClick: () -> Unit): Modifier =
    liquid(shape = null, color = Color.Transparent, enabled = enabled, role = role, onClickLabel = onClickLabel, onClick = onClick)

// ---------- Navegación inferior flotante ----------

data class NavItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun FloatingNavBar(items: List<NavItem>, current: String?, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    val haze = LocalHaze.current
    val shape = RoundedCornerShape(32.dp)
    Row(
        modifier
            .padding(horizontal = 14.dp)
            .shadow(10.dp, shape, ambientColor = Color.Black.copy(alpha = 0.25f), spotColor = Color.Black.copy(alpha = 0.30f))
            .glass(shape, haze)
            .fillMaxWidth()
            .heightIn(min = 68.dp)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEach { item ->
            val selected = item.route == current
            Column(
                Modifier.weight(1f).heightIn(min = 56.dp)
                    .liquid(RoundedCornerShape(26.dp), if (selected) C.Blue.copy(alpha = 0.16f) else Color.Transparent, role = Role.Tab) { onSelect(item.route) }
                    .semantics { this.selected = selected }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(item.icon, null, tint = if (selected) C.Blue else C.TextSec, modifier = Modifier.size(24.dp))
                Spacer(Modifier.height(2.dp))
                Text(item.label, style = T.Label.copy(fontSize = 11.sp, color = if (selected) C.Text else C.TextSec), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ---------- Menús anclados, diálogos y páginas ----------

enum class PanelKind { MENU, DIALOG, PAGE }

class PanelEntry(val kind: PanelKind, val anchor: Rect?, val title: String?, val content: @Composable ColumnScope.() -> Unit)

/**
 * Sustituye al antiguo SheetHost que colocaba todo abajo:
 *  - show/pick: menú que se despliega DESDE el control pulsado (debajo si cabe, encima si está cerca del borde inferior,
 *    alineado hacia dentro si está junto a un lateral), con el origen de la animación en el punto de unión.
 *  - dialog/confirm: diálogo centrado, solo para confirmaciones delicadas.
 *  - page: formulario extenso a pantalla completa.
 * Un toque fuera, Atrás o una selección cierran el panel.
 */
class SheetController {
    private var lastAnchor: Rect? = null
    private var anchorTime = 0L
    var entry by mutableStateOf<PanelEntry?>(null)
        private set

    fun anchorAt(r: Rect) { lastAnchor = r; anchorTime = SystemClock.uptimeMillis() }
    private fun fresh(): Rect? = lastAnchor?.takeIf { SystemClock.uptimeMillis() - anchorTime < 2500 && it.width > 0f }

    fun show(c: @Composable ColumnScope.() -> Unit) { entry = PanelEntry(PanelKind.MENU, fresh(), null, c) }
    fun dialog(c: @Composable ColumnScope.() -> Unit) { entry = PanelEntry(PanelKind.DIALOG, null, null, c) }
    fun page(title: String, c: @Composable ColumnScope.() -> Unit) { entry = PanelEntry(PanelKind.PAGE, null, title, c) }
    fun hide() { entry = null }

    fun confirm(title: String, message: String, confirmLabel: String, color: Color, icon: ImageVector? = null, onConfirm: () -> Unit) = dialog {
        Text(title, style = T.Section, modifier = Modifier.semantics { heading() })
        Spacer(Modifier.height(8.dp))
        Text(message, style = T.Body.copy(color = C.TextSec))
        Spacer(Modifier.height(20.dp))
        PillButton(confirmLabel, color = color, icon = icon, modifier = Modifier.fillMaxWidth()) { hide(); onConfirm() }
        Spacer(Modifier.height(10.dp))
        PillButton("Cancelar", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { hide() }
    }

    fun <O> pick(
        title: String, options: List<O>, label: (O) -> String, selected: O?,
        icon: ((O) -> ImageVector?)? = null, tint: ((O) -> Color)? = null, subtitle: ((O) -> String?)? = null,
        onPick: (O) -> Unit,
    ) = show {
        MenuTitle(title)
        options.forEach { o ->
            MenuRow(label(o), icon?.invoke(o), tint?.invoke(o) ?: C.Text, selected = o == selected, subtitle = subtitle?.invoke(o)) { hide(); onPick(o) }
        }
    }
}

val LocalSheet = staticCompositionLocalOf { SheetController() }

@Composable
fun MenuTitle(text: String) {
    Text(text, style = T.Label, modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 4.dp).semantics { heading() })
}

/** Fila de menú: pictograma, nombre y marca de selección. Objetivo táctil ≥ 48 dp. */
@Composable
fun MenuRow(label: String, icon: ImageVector? = null, tint: Color = C.Text, selected: Boolean = false, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp)
            .liquid(RoundedCornerShape(16.dp), if (selected) tint.copy(alpha = 0.14f) else Color.Transparent, role = Role.RadioButton, onClick = onClick)
            .semantics { this.selected = selected }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(label, style = T.BodyStrong)
            if (subtitle != null) Text(subtitle, style = T.Label)
        }
        if (selected) Icon(Icons.Rounded.Check, "Seleccionado", tint = if (tint == C.Text) C.Blue else tint, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun SheetHost(controller: SheetController) {
    val entry = controller.entry
    var shown by remember { mutableStateOf<PanelEntry?>(null) }
    val progress = remember { Animatable(0f) }
    val reduce = LocalReduceMotion.current
    LaunchedEffect(entry) {
        if (entry != null) {
            shown = entry
            progress.snapTo(0f)
            if (reduce) progress.snapTo(1f) else progress.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = 650f))
        } else if (shown != null) {
            if (reduce) progress.snapTo(0f) else progress.animateTo(0f, tween(130))
            shown = null
        }
    }
    BackHandler(enabled = entry != null) { controller.hide() }
    val s = shown ?: return
    val p = { progress.value.coerceIn(0f, 1f) }
    if (s.kind != PanelKind.PAGE) Box(Modifier.fillMaxSize().graphicsLayer { alpha = p() }.background(C.Scrim)
        .pointerInput(s) { detectTapGestures { controller.hide() } })
    when (s.kind) {
        PanelKind.MENU -> AnchoredPanel(s, p)
        PanelKind.DIALOG -> CenteredPanel(s, p)
        PanelKind.PAGE -> PagePanel(s, p) { controller.hide() }
    }
}

@Composable
private fun PanelSurface(modifier: Modifier, padding: Dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier
            .shadow(12.dp, shape, ambientColor = Color.Black.copy(alpha = 0.25f), spotColor = Color.Black.copy(alpha = 0.30f))
            .glass(shape, LocalHaze.current)
            // Absorbe toques dentro del panel para que no lo cierren.
            .pointerInput(Unit) { detectTapGestures { } }
            .semantics { paneTitle = "Menú" }
            .verticalScroll(rememberScrollState())
            .padding(padding),
        content = content,
    )
}

/** Mide los límites del control y coloca el panel debajo, encima o hacia dentro, dentro de los márgenes seguros. */
@Composable
private fun AnchoredPanel(e: PanelEntry, progress: () -> Float) {
    val d = LocalDensity.current
    val insets = WindowInsets.safeDrawing
    Layout(
        content = { PanelSurface(Modifier, 8.dp, e.content) },
        modifier = Modifier.fillMaxSize(),
    ) { measurables, cons ->
        val w = cons.maxWidth; val h = cons.maxHeight
        val margin = 12.dp.roundToPx(); val gap = 8.dp.roundToPx()
        val top = insets.getTop(d) + margin
        val bottom = h - insets.getBottom(d) - margin
        val a = e.anchor ?: Rect(w / 2f, h / 2f, w / 2f, h / 2f)
        val spaceBelow = bottom - (a.bottom.toInt() + gap)
        val spaceAbove = (a.top.toInt() - gap) - top
        val maxW = (w - 2 * margin).coerceAtLeast(1)
        val desiredW = maxOf(a.width.toInt(), 264.dp.roundToPx()).coerceAtMost(360.dp.roundToPx()).coerceAtMost(maxW)
        val maxH = maxOf(spaceBelow, spaceAbove, 180.dp.roundToPx()).coerceAtMost((bottom - top).coerceAtLeast(1))
        val pl = measurables.first().measure(Constraints(minWidth = desiredW, maxWidth = desiredW, minHeight = 0, maxHeight = maxH))
        val below = e.anchor == null || pl.height <= spaceBelow || spaceBelow >= spaceAbove
        val rawY = when {
            e.anchor == null -> (h - pl.height) / 2
            below -> a.bottom.toInt() + gap
            else -> a.top.toInt() - gap - pl.height
        }
        val y = rawY.coerceAtMost(bottom - pl.height).coerceAtLeast(top)
        val alignRight = a.center.x > w / 2f
        val rawX = if (e.anchor == null) (w - pl.width) / 2 else if (alignRight) a.right.toInt() - pl.width else a.left.toInt()
        val x = rawX.coerceAtMost(w - margin - pl.width).coerceAtLeast(margin)
        val px = if (pl.width > 0) ((a.center.x - x) / pl.width).coerceIn(0f, 1f) else 0.5f
        val py = if (e.anchor == null) 0.5f else if (below) 0f else 1f
        layout(w, h) {
            pl.placeWithLayer(x, y) {
                val k = progress()
                alpha = k; scaleX = 0.90f + 0.10f * k; scaleY = 0.80f + 0.20f * k
                transformOrigin = TransformOrigin(px, py)
            }
        }
    }
}

@Composable
private fun CenteredPanel(e: PanelEntry, progress: () -> Float) {
    Box(Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp), contentAlignment = Alignment.Center) {
        PanelSurface(Modifier.widthIn(max = 420.dp).fillMaxWidth().graphicsLayer {
            val k = progress(); alpha = k; scaleX = 0.94f + 0.06f * k; scaleY = 0.94f + 0.06f * k
        }, 22.dp, e.content)
    }
}

@Composable
private fun PagePanel(e: PanelEntry, progress: () -> Float, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().graphicsLayer { val k = progress(); alpha = k; translationY = (1f - k) * 48.dp.toPx() }
        .background(C.Bg).pointerInput(Unit) { detectTapGestures { } }.statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(e.title ?: "", style = T.ScreenTitle, modifier = Modifier.weight(1f).semantics { heading() })
            RoundIconButton(Icons.Rounded.Close, "Cerrar", onClick = onClose)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), content = e.content)
    }
}

// ---------- Botones y bloques ----------

@Composable
fun PillButton(
    text: String, modifier: Modifier = Modifier, color: Color = C.Blue, textColor: Color = C.OnColor,
    icon: ImageVector? = null, enabled: Boolean = true, big: Boolean = false, onClick: () -> Unit,
) {
    Row(
        modifier.heightIn(min = if (big) 64.dp else 52.dp)
            .liquid(RoundedCornerShape(percent = 50), if (enabled) color else C.Control.copy(alpha = 0.6f), enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
    ) {
        if (icon != null) { Icon(icon, null, tint = if (enabled) textColor else C.TextSec, modifier = Modifier.size(if (big) 28.dp else 22.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, style = (if (big) T.BodyStrong.copy(fontSize = 19.sp) else T.BodyStrong).copy(color = if (enabled) textColor else C.TextSec),
            textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, description: String, modifier: Modifier = Modifier, bg: Color = C.Control, tint: Color = C.Text, onClick: () -> Unit) {
    Box(modifier.size(48.dp).liquid(CircleShape, bg, onClickLabel = description, onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
    }
}

@Composable
fun CircleAction(icon: ImageVector, label: String, tint: Color = C.Text, bg: Color = C.Control, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        Box(Modifier.size(54.dp).liquid(CircleShape, bg, onClick = onClick).semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = T.Label.copy(color = C.Text), textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
fun FCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, color: Color = C.Card, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.liquid(shape, color, onClick = onClick) else Modifier.clip(shape).background(color))
            .padding(18.dp),
        content = content,
    )
}

@Composable
fun ListRow(title: String, subtitle: String? = null, leading: ImageVector? = null, leadingTint: Color = C.Text,
            trailing: ImageVector? = Icons.Rounded.ChevronRight, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp)
            .then(if (onClick != null) Modifier.liquid(RoundedCornerShape(16.dp), Color.Transparent, onClick = onClick) else Modifier)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(if (leadingTint == C.Text) C.Control else leadingTint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center) { Icon(leading, null, tint = leadingTint, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            if (subtitle != null) Text(subtitle, style = T.Label)
        }
        if (trailing != null && onClick != null) Icon(trailing, null, tint = C.TextSec)
    }
}

@Composable
fun Stat(label: String, value: String, unit: String? = null, modifier: Modifier = Modifier, big: Boolean = false) {
    Column(modifier) {
        Text(label, style = T.Label)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = if (big) T.HomeFigure else T.Number)
            if (unit != null) { Spacer(Modifier.width(4.dp)); Text(unit, style = T.Label, modifier = Modifier.padding(bottom = 3.dp)) }
        }
    }
}

@Composable
fun Tag(text: String, color: Color = C.Control, textColor: Color = C.Text) {
    Text(text, style = T.Label.copy(color = textColor), modifier = Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 4.dp))
}

/** Nombre visible de la marca, en Inter Regular. (La silueta del logotipo antiguo no se puede aislar: ver docs/MARCA.md.) */
@Composable
fun BrandName(modifier: Modifier = Modifier, size: Int = 24) {
    Text("Athlete Club", style = T.Section.copy(fontSize = size.sp), modifier = modifier.semantics { heading() })
}

@Composable
fun <O> ChoiceChips(options: List<O>, label: (O) -> String, isSelected: (O) -> Boolean, onToggle: (O) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            val sel = isSelected(o)
            Box(Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), if (sel) C.Text else C.Control, role = Role.Checkbox) { onToggle(o) }
                .semantics { selected = sel }.padding(horizontal = 16.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(label(o), style = T.Body.copy(color = if (sel) C.Bg else C.Text))
            }
        }
    }
}

/**
 * Pantalla con cabecera fija y lista desplazable. La lista reserva espacio para la cápsula inferior
 * y aplica la difuminación superior solo cuando hay contenido saliendo por arriba.
 */
@Composable
fun ScreenScaffold(
    title: String?,
    header: (@Composable RowScope.() -> Unit)? = null,
    state: LazyListState = rememberLazyListState(),
    content: LazyListScope.() -> Unit,
) {
    val fade = 32.dp
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            if (title != null) Text(title, style = T.ScreenTitle, modifier = Modifier.weight(1f).semantics { heading() }) else Spacer(Modifier.weight(1f))
            header?.invoke(this)
        }
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize().topFade(fade, state.canScrollBackward),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = LocalNavPadding.current + 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content,
        )
    }
}

@Composable
fun SectionTitle(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = T.Section, modifier = Modifier.weight(1f).semantics { heading() })
        if (action != null && onAction != null) Text(action, style = T.BodyStrong.copy(color = C.Blue),
            modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50), onClick = onAction).padding(horizontal = 10.dp, vertical = 12.dp))
    }
}

@Composable
fun Notice(text: String, color: Color = C.Control, icon: ImageVector = Icons.Rounded.Info, textColor: Color = C.Text) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = textColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = textColor, fontSize = 14.sp))
    }
}

/** Indicación de un solo paso para funciones secundarias. Se puede cerrar y volver a abrir desde «?». */
@Composable
fun Hint(text: String, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Blue.copy(alpha = 0.12f)).padding(start = 14.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Lightbulb, null, tint = C.Blue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(fontSize = 14.sp), modifier = Modifier.weight(1f))
        RoundIconButton(Icons.Rounded.Close, "Cerrar ayuda", bg = Color.Transparent, tint = C.TextSec, onClick = onClose)
    }
}

@Composable
fun rememberNavHeight(onHeight: (Dp) -> Unit): Modifier {
    val d = LocalDensity.current
    return Modifier.onSizeChanged { onHeight(with(d) { it.height.toDp() }) }
}
