package app.fuckrun.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.account.AccountState
import app.fuckrun.domain.Sport
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Tras la bienvenida o la cuenta: el tutorial la primera vez, Inicio después. */
private suspend fun continueAfterWelcome(nav: NavController) {
    val app = FuckrunApp.instance
    app.device.setWelcomeSeen()
    val seen = app.device.tutorialSeen.first()
    nav.navigate(if (seen) Routes.HOME else Routes.tutorial()) { popUpTo(0) }
}

/** Bienvenida: «Crear cuenta», «Iniciar sesión» y «Continuar sin cuenta». */
@Composable
fun WelcomeScreen(nav: NavController) {
    val app = FuckrunApp.instance
    val scope = rememberCoroutineScope()
    val account by app.account.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Sport.entries.forEach { SportBadge(it, 52.dp) } }
        Spacer(Modifier.height(28.dp))
        BrandName(size = 44)
        Spacer(Modifier.height(10.dp))
        Text("Elige un deporte, sal a practicarlo y guarda tu recorrido en un historial privado. Prepara entrenamientos y queda con tu club.",
            style = T.Body.copy(color = C.TextSec, fontSize = 17.sp))
        Spacer(Modifier.weight(1f))
        if (account != AccountState.NotConfigured && account !is AccountState.SignedIn) {
            PillButton("Crear cuenta", color = C.Green, icon = Icons.Rounded.PersonAdd, big = true, modifier = Modifier.fillMaxWidth()) { nav.navigate(Routes.account("create")) }
            Spacer(Modifier.height(10.dp))
            PillButton("Iniciar sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Login, modifier = Modifier.fillMaxWidth()) { nav.navigate(Routes.account("signin")) }
            Spacer(Modifier.height(10.dp))
        }
        PillButton("Continuar sin cuenta", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { scope.launch { continueAfterWelcome(nav) } }
        Text(if (account == AccountState.NotConfigured) "Esta versión funciona sin cuenta: tus actividades se guardan en este móvil."
            else "Sin cuenta, tus actividades se guardan solo en este móvil. Puedes crearla más tarde en Perfil.",
            style = T.Label, modifier = Modifier.padding(top = 10.dp))
    }
}

/**
 * Crear cuenta (correo, contraseña y nombre de usuario), iniciar sesión (correo y contraseña) y recuperar contraseña.
 * La contraseña no se guarda en la app: la gestiona el servicio de autenticación.
 */
@Composable
fun AccountScreen(nav: NavController, mode0: String) {
    val app = FuckrunApp.instance
    val scope = rememberCoroutineScope()
    var mode by rememberSaveable { mutableStateOf(mode0) }   // create | signin | reset
    var email by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val emailOk = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$").matches(email.trim())
    val valid = when (mode) { "create" -> emailOk && password.length >= 8 && username.trim().length >= 2; "signin" -> emailOk && password.isNotEmpty(); else -> emailOk }
    val fromWelcome = nav.previousBackStackEntry?.destination?.route == Routes.WELCOME

    fun finish() = scope.launch { if (fromWelcome) continueAfterWelcome(nav) else nav.popBackStack() }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(when (mode) { "create" -> "Crear cuenta"; "signin" -> "Iniciar sesión"; else -> "Recuperar contraseña" }, style = T.ScreenTitle, modifier = Modifier.weight(1f))
            RoundIconButton(Icons.Rounded.Close, "Cerrar") { nav.popBackStack() }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (app.account.state.value == AccountState.NotConfigured) Notice("La cuenta no está configurada en esta versión. Puedes seguir sin cuenta: todo se guarda en este móvil.",
                icon = Icons.Rounded.CloudOff)
            Label("Correo electrónico")
            InputField(email, "nombre@ejemplo.com", KeyboardType.Email) { email = it.trim() }
            if (mode == "create") { Label("Nombre de usuario"); InputField(username, "Cómo te verá tu club", KeyboardType.Text) { username = it.take(30) } }
            if (mode != "reset") {
                Label("Contraseña")
                InputField(password, if (mode == "create") "Al menos 8 caracteres" else "Tu contraseña", KeyboardType.Password, secret = !showPass) { password = it }
                Text(if (showPass) "Ocultar contraseña" else "Mostrar contraseña", style = T.Label.copy(color = C.Blue),
                    modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { showPass = !showPass }.padding(horizontal = 8.dp, vertical = 14.dp))
            }
            error?.let { Box(Modifier.semantics { liveRegion = LiveRegionMode.Polite }) { Notice(it, color = C.Red.copy(alpha = 0.14f), icon = Icons.Rounded.ErrorOutline) } }
            info?.let { Box(Modifier.semantics { liveRegion = LiveRegionMode.Polite }) { Notice(it, color = C.Green.copy(alpha = 0.14f), icon = Icons.Rounded.MarkEmailRead) } }
            PillButton(if (busy) "Un momento…" else when (mode) { "create" -> "Crear cuenta"; "signin" -> "Iniciar sesión"; else -> "Enviar enlace" },
                color = C.Green, enabled = valid && !busy, big = true, modifier = Modifier.fillMaxWidth()) {
                busy = true; error = null; info = null
                scope.launch {
                    runCatching {
                        when (mode) {
                            "create" -> { app.account.create(email, password, username); app.graph.profile.update { it.copy(sharedDisplayName = username.trim()) }; finish() }
                            "signin" -> { app.account.signIn(email, password); finish() }
                            else -> { app.account.resetPassword(email); info = "Si existe una cuenta con ese correo, te hemos enviado un enlace para crear una contraseña nueva." }
                        }
                    }.onFailure { error = it.message }
                    busy = false
                }
            }
            when (mode) {
                "create" -> {
                    Text("Te enviaremos un correo para verificar tu dirección. Tus actividades se copiarán en un espacio privado de tu cuenta: nadie más del club puede verlas.", style = T.Label)
                    LinkText("¿Ya tienes cuenta? Inicia sesión") { mode = "signin"; error = null }
                }
                "signin" -> {
                    LinkText("He olvidado mi contraseña") { mode = "reset"; error = null }
                    LinkText("No tengo cuenta: crear una") { mode = "create"; error = null }
                }
                else -> LinkText("Volver a iniciar sesión") { mode = "signin"; error = null; info = null }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable private fun Label(t: String) = Text(t, style = T.BodyStrong, modifier = Modifier.padding(start = 4.dp, top = 4.dp))

@Composable
private fun LinkText(t: String, onClick: () -> Unit) {
    Text(t, style = T.Body.copy(color = C.Blue), modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).liquid(RoundedCornerShape(16.dp), onClick = onClick)
        .padding(horizontal = 6.dp, vertical = 12.dp))
}

@Composable
private fun InputField(value: String, placeholder: String, type: KeyboardType, secret: Boolean = false, onChange: (String) -> Unit) {
    Box(Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(18.dp)).background(C.Card).padding(16.dp)) {
        if (value.isEmpty()) Text(placeholder, style = T.Body.copy(color = C.TextSec))
        BasicTextField(value, onChange, textStyle = T.Body, cursorBrush = SolidColor(C.Blue), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = type, autoCorrectEnabled = false),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth().semantics { contentDescription = placeholder })
    }
}
