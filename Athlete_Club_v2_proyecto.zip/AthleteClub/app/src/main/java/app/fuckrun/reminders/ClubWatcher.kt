package app.fuckrun.reminders

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.fuckrun.FuckrunApp
import app.fuckrun.MainActivity
import app.fuckrun.R

/**
 * Avisa de cambios relevantes (hora, lugar, cancelación…) en sesiones a las que asistes, mientras la app
 * está abierta y conectada. Para avisos con la app cerrada hace falta push (FCM + Cloud Functions): ver docs/SERVICIOS.md.
 * La primera lectura no genera avisos; nunca se avisa de cambios hechos por uno mismo.
 */
suspend fun watchClubChanges(ctx: Context) {
    val g = FuckrunApp.graph
    val seen = mutableMapOf<String, Pair<Long, String>>()
    var first = true
    g.shared.mySessions().collect { list ->
        val me = g.shared.currentUid()
        for (s in list) {
            val prev = seen[s.id]
            val now = s.updatedAt to s.lastChangeNote
            if (!first && prev != null && s.updatedAt > prev.first && s.organizerUid != me && s.lastChangeNote.isNotBlank() && s.lastChangeNote != prev.second) {
                val nm = NotificationManagerCompat.from(ctx)
                if (nm.areNotificationsEnabled()) runCatching {
                    val open = PendingIntent.getActivity(ctx, s.id.hashCode(), Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    nm.notify(s.id.hashCode(), NotificationCompat.Builder(ctx, FuckrunApp.CH_CLUB).setSmallIcon(R.drawable.ic_stat_run)
                        .setContentTitle(s.name).setContentText(s.lastChangeNote).setContentIntent(open).setAutoCancel(true).build())
                }
            }
            seen[s.id] = now
        }
        if (list.isNotEmpty()) first = false
    }
}
