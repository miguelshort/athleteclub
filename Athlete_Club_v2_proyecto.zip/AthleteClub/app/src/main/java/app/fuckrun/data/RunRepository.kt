package app.fuckrun.data

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import app.fuckrun.data.db.*
import app.fuckrun.domain.Sport
import app.fuckrun.domain.SportRules
import app.fuckrun.domain.metrics.RunMetrics
import kotlinx.coroutines.flow.Flow

/** Reloj del dispositivo: pared + monotónico + número de arranque (para detectar reinicios). */
class DeviceClock(private val ctx: Context) {
    fun wall() = System.currentTimeMillis()
    fun mono() = SystemClock.elapsedRealtime()
    fun boot(): Int = try { Settings.Global.getInt(ctx.contentResolver, Settings.Global.BOOT_COUNT) } catch (_: Exception) { -1 }
}

data class RunDetail(val run: RunEntity, val stats: RunMetrics.Stats, val events: List<EventEntity>)

fun PointEntity.toSample() = RunMetrics.Sample(segment, monoMs, wallMs, lat, lon, accuracyM, altitudeM)

val RunEntity.sportEnum: Sport get() = Sport.of(sport)

class RunRepository(private val db: AppDatabase, val clock: DeviceClock) {
    private val dao = db.runs()
    /** Se llama tras cada cambio que deba copiarse en la cuenta. */
    var onChange: () -> Unit = {}

    fun finishedRuns(): Flow<List<RunEntity>> = dao.finished()
    fun observe(id: Long) = dao.observe(id)
    suspend fun get(id: Long) = dao.get(id)
    suspend fun unfinished() = dao.unfinished()

    suspend fun startRun(sport: Sport, kind: String, plannedId: Long?, routeId: String?, sharedId: String?, sharedName: String?): Long {
        val now = clock.wall()
        val id = dao.insert(RunEntity(startedAtWall = now, status = RunStatus.RECORDING, kind = kind, sport = sport.name,
            plannedSessionId = plannedId, routeId = routeId, sharedSessionId = sharedId, sharedSessionName = sharedName))
        event(id, EventType.START)
        return id
    }

    suspend fun event(runId: Long, type: String, detail: String = "") =
        dao.insertEvent(EventEntity(runId = runId, type = type, wallMs = clock.wall(), monoMs = clock.mono(), bootCount = clock.boot(), detail = detail))

    suspend fun addPoint(p: PointEntity) = dao.insertPoint(p)
    suspend fun update(run: RunEntity) = dao.update(run)

    /** Cambio hecho por el usuario sobre una actividad guardada (nota, deporte…): se marca pendiente de copia. */
    suspend fun edit(run: RunEntity) { dao.update(run.copy(updatedAt = clock.wall())); onChange() }

    /** Convierte eventos en intervalos activos expresados en una base de pared corregida. */
    internal fun intervals(events: List<EventEntity>, nowWall: Long, nowMono: Long, nowBoot: Int): List<RunMetrics.Interval> {
        val res = mutableListOf<RunMetrics.Interval>()
        var open: EventEntity? = null
        for (e in events) when (e.type) {
            EventType.START, EventType.RESUME -> if (open == null) open = e
            EventType.PAUSE, EventType.STOP, EventType.INTERRUPTED -> open?.let { o ->
                val dur = if (o.bootCount == e.bootCount && e.monoMs >= o.monoMs) e.monoMs - o.monoMs else (e.wallMs - o.wallMs)
                res += RunMetrics.Interval(o.wallMs, o.wallMs + dur.coerceAtLeast(0)); open = null
            }
        }
        open?.let { o ->
            val dur = if (o.bootCount == nowBoot) nowMono - o.monoMs else nowWall - o.wallMs
            res += RunMetrics.Interval(nowWall - dur, null)   // se cierra con nowWall
        }
        return res
    }

    internal fun elapsed(events: List<EventEntity>, end: EventEntity?, nowWall: Long, nowMono: Long, nowBoot: Int): Long {
        val start = events.firstOrNull { it.type == EventType.START } ?: return 0
        return if (end != null) {
            if (end.bootCount == start.bootCount) end.monoMs - start.monoMs else end.wallMs - start.wallMs
        } else {
            if (nowBoot == start.bootCount) nowMono - start.monoMs else nowWall - start.wallMs
        }.coerceAtLeast(0)
    }

    suspend fun detail(runId: Long, live: Boolean = false): RunDetail? {
        val run = dao.get(runId) ?: return null
        val events = dao.events(runId)
        val samples = dao.points(runId).map { it.toSample() }
        return RunDetail(run, stats(run, events, samples, live), events)
    }

    /** Cálculo único usado por el servicio en directo y por el resumen/detalle. */
    fun stats(run: RunEntity, events: List<EventEntity>, samples: List<RunMetrics.Sample>, live: Boolean): RunMetrics.Stats {
        val nowWall = clock.wall(); val nowMono = clock.mono(); val nowBoot = clock.boot()
        val stopEvent = events.lastOrNull { it.type == EventType.STOP }
        val elapsed = elapsed(events, stopEvent, nowWall, nowMono, nowBoot)
        val endWall = if (stopEvent != null) run.startedAtWall + elapsed else null
        val sport = run.sportEnum
        return RunMetrics.compute(
            maxPlausibleMps = SportRules.maxPlausibleMps(sport),
            currentWindowMs = SportRules.windowMs(sport),
            raw = samples,
            intervals = intervals(events, nowWall, nowMono, nowBoot),
            startWallMs = if (endWall == null) nowWall - elapsed else run.startedAtWall,
            endWallMs = endWall,
            nowMs = nowWall,
            nowMonotonicMs = nowMono,
            recording = live && run.status == RunStatus.RECORDING,
        )
    }

    suspend fun events(runId: Long) = dao.events(runId)

    /** Detiene la captura: guarda el resumen y deja la sesión pendiente de guardar/descartar. */
    suspend fun endRecording(runId: Long) {
        val run = dao.get(runId) ?: return
        if (run.status == RunStatus.RECORDING || run.status == RunStatus.PAUSED) event(runId, EventType.STOP)
        val d = detail(runId) ?: return
        dao.update(run.copy(
            status = RunStatus.ENDED_UNSAVED, endedAtWall = run.startedAtWall + d.stats.elapsedMs,
            distanceM = d.stats.distanceM.takeIf { d.stats.acceptedPoints >= 2 },
            elapsedMs = d.stats.elapsedMs, activeMs = d.stats.activeMs,
            avgSpeedMps = d.stats.avgSpeedMps, maxSpeedMps = d.stats.maxSpeedMps, minMovingSpeedMps = d.stats.minMovingSpeedMps,
            elevationGainM = d.stats.elevationGainM,
            gapCount = d.events.count { it.type in setOf(EventType.SIGNAL_LOST, EventType.INTERRUPTED, EventType.GPS_OFF, EventType.PERMISSION_LOST) },
        ))
    }

    suspend fun save(runId: Long, note: String) {
        val run = dao.get(runId) ?: return
        dao.update(run.copy(status = RunStatus.FINISHED, note = note, updatedAt = clock.wall()))
        onChange()
    }

    /**
     * Descarta (resumen) o elimina (historial). Deja constancia del borrado para que una restauración o
     * un reintento de copia no lo recupere.
     */
    suspend fun discard(runId: Long) {
        val run = dao.get(runId)
        db.routines().unlinkRun(runId)
        dao.delete(runId)
        if (run != null && run.status == RunStatus.FINISHED) {
            db.tombstones().put(TombstoneEntity(run.syncId, "RUN"))
            onChange()
        }
    }

    /** Recalcula el resumen de una actividad a partir de sus puntos y eventos (tras restaurar desde la cuenta). */
    suspend fun recompute(runId: Long) {
        val run = dao.get(runId) ?: return
        if (run.source == RunSource.MANUAL) return
        val d = detail(runId) ?: return
        dao.update(run.copy(
            distanceM = d.stats.distanceM.takeIf { d.stats.acceptedPoints >= 2 },
            elapsedMs = d.stats.elapsedMs, activeMs = d.stats.activeMs,
            avgSpeedMps = d.stats.avgSpeedMps, maxSpeedMps = d.stats.maxSpeedMps, minMovingSpeedMps = d.stats.minMovingSpeedMps,
            elevationGainM = d.stats.elevationGainM,
        ))
    }

    /**
     * Recuperación tras cierre del proceso o reinicio: registra el tramo perdido desde el último dato
     * conocido. Al continuar se abre un segmento nuevo; el hueco nunca se dibuja como recorrido.
     */
    suspend fun markInterrupted(runId: Long): Long {
        val run = dao.get(runId) ?: return 0
        val lastP = dao.lastPoint(runId)
        val lastE = dao.events(runId).lastOrNull()
        val anchor = listOfNotNull(lastP?.let { Triple(it.wallMs, it.monoMs, it.bootCount) }, lastE?.let { Triple(it.wallMs, it.monoMs, it.bootCount) })
            .maxByOrNull { it.first } ?: return 0
        // Solo hay tramo perdido si se estaba grabando; si estaba en pausa no se pierde tiempo activo.
        val lost = if (run.status == RunStatus.RECORDING) (clock.wall() - anchor.first).coerceAtLeast(0) else 0L
        if (run.status == RunStatus.RECORDING) {
            dao.insertEvent(EventEntity(runId = runId, type = EventType.INTERRUPTED, wallMs = anchor.first, monoMs = anchor.second,
                bootCount = anchor.third, detail = "Proceso detenido o dispositivo reiniciado"))
        }
        dao.update(run.copy(status = RunStatus.PAUSED, lostMs = run.lostMs + lost, currentSegment = run.currentSegment + 1))
        return lost
    }

    /** Registro manual: contiene SOLO los datos introducidos (sin ruta, máximos ni mínimos). */
    suspend fun addManual(sport: Sport, startWall: Long, activeMs: Long, distanceM: Double?, note: String): Long =
        dao.insert(RunEntity(startedAtWall = startWall, endedAtWall = startWall + activeMs, status = RunStatus.FINISHED, sport = sport.name,
            source = RunSource.MANUAL, note = note, distanceM = distanceM, elapsedMs = activeMs, activeMs = activeMs,
            avgSpeedMps = if (distanceM != null && activeMs > 0) distanceM / (activeMs / 1000.0) else null)).also { onChange() }

    suspend fun points(runId: Long) = dao.points(runId)
    suspend fun finishedCount() = dao.finishedCount()

    /** Borra todo el historial de este perfil, dejando constancia para que la cuenta también lo olvide. */
    suspend fun deleteAll() {
        dao.finishedOnce().forEach { db.tombstones().put(TombstoneEntity(it.syncId, "RUN")) }
        dao.deleteAll()
        onChange()
    }
}
