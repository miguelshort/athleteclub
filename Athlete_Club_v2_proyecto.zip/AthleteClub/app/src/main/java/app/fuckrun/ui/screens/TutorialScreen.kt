package app.fuckrun.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.MusicProvider
import app.fuckrun.data.db.RunEntity
import app.fuckrun.data.db.RunStatus
import app.fuckrun.domain.Sport
import app.fuckrun.topLevel
import app.fuckrun.tracking.SignalQuality
import app.fuckrun.tracking.StartFailure
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.launch

/**
 * «Cómo se usa»: aparece la primera vez que se abre la instalación y se puede repetir desde Perfil → Cómo se usa.
 * Cada lámina muestra los controles REALES de esta versión (los mismos componentes que usa la app, en el tema actual),
 * con el control resaltado y una frase que dice qué tocar y qué pasará. Los ejemplos son inertes: no se pueden pulsar,
 * no inician el GPS ni crean actividades.
 */
@Composable
fun TutorialScreen(nav: NavController, replay: Boolean) {
    val app = FuckrunApp.instance
    val scope = rememberCoroutineScope()
    var page by androidx.compose.runtime.saveable.rememberSaveable { mutableIntStateOf(0) }
    val slides = slides()
    fun finish() = scope.launch {
        app.device.setTutorialSeen(true)
        if (replay && nav.previousBackStackEntry != null) nav.popBackStack() else nav.navigate(Routes.HOME) { popUpTo(0) }
    }
    BackHandler(enabled = page > 0) { page-- }

    Column(Modifier.fillMaxSize().background(C.Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Cómo se usa", style = T.BodyStrong, modifier = Modifier.weight(1f))
            if (page < slides.lastIndex) Text("Saltar", style = T.Body.copy(color = C.Blue),
                modifier = Modifier.heightIn(min = 48.dp).liquid(RoundedCornerShape(50)) { finish() }.padding(horizontal = 14.dp, vertical = 12.dp))
        }
        // Indicador de avance
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).semantics { contentDescription = "Paso ${page + 1} de ${slides.size}" },
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            slides.indices.forEach { i -> Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(if (i <= page) C.Blue else C.Control)) }
        }
        AnimatedContent(page, modifier = Modifier.weight(1f), transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "lamina") { p ->
            val s = slides[p]
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(s.title, style = T.ScreenTitle)
                s.preview()
                Text(s.text, style = T.Body.copy(fontSize = 18.sp), modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            }
        }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (page > 0) PillButton("Atrás", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) { page-- }
            if (page < slides.lastIndex) PillButton("Siguiente", color = C.Text, textColor = C.Bg, modifier = Modifier.weight(1f)) { page++ }
            else PillButton("Empezar a usar Athlete Club", color = C.Green, modifier = Modifier.weight(2f)) { finish() }
        }
    }
}


private class Slide(val title: String, val text: String, val preview: @Composable () -> Unit)

private fun slides() = listOf(
    Slide("Inicio y barra inferior", "Empieza aquí. La barra de abajo te lleva a Rutas, Club, Rutinas y Progreso.") {
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandName(); Spacer(Modifier.weight(1f))
                Highlight(CircleShape, "Perfil") { RoundIconButton(Icons.Rounded.Person, "Perfil") {} }
            }
            Spacer(Modifier.height(10.dp))
            FCard {
                Text("Tu próxima actividad", style = T.Label); Spacer(Modifier.height(8.dp))
                SportSelector(Sport.RUN) {}
                Spacer(Modifier.height(10.dp))
                PillButton("Empezar actividad", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {}
            }
            Spacer(Modifier.height(12.dp))
            Highlight(RoundedCornerShape(34.dp), "Barra") { FloatingNavBar(topLevel, "home", onSelect = {}, modifier = Modifier) }
        }
    },
    Slide("Elegir deporte", "Toca el deporte y elige Correr, Sendero, Bicicleta o Caminata.") {
        Frame {
            Highlight(RoundedCornerShape(26.dp), "Selector de deporte") { SportSelector(Sport.HIKE) {} }
            Spacer(Modifier.height(8.dp))
            MenuPreview {
                MenuTitle("Deporte")
                Sport.entries.forEach { MenuRow(it.label, it.icon, it.color, selected = it == Sport.HIKE) {} }
            }
        }
    },
    Slide("Preparar la salida", "Elige tu música y vuelve aquí. Toca Empezar cuando estés listo.") {
        Frame {
            Highlight(RoundedCornerShape(22.dp), "Música") { MusicRow(MusicProvider.SPOTIFY, onChoose = {}, onOpen = {}) }
            Spacer(Modifier.height(10.dp))
            Highlight(RoundedCornerShape(22.dp), "GPS") { GpsRow(StartFailure.PERMISSION, SignalQuality.NONE, null, highlight = false) {} }
            Text("Permite la ubicación para dibujar tu recorrido.", style = T.Label, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
        }
        Frame {
            Highlight(RoundedCornerShape(36.dp), "Empezar") {
                PillButton("Empezar", color = C.Green, icon = Icons.Rounded.PlayArrow, big = true, modifier = Modifier.fillMaxWidth()) {}
            }
        }
    },
    Slide("Registrar y guardar", "Pausa cuando pares. Para guardar, toca Terminar y después Guardar actividad.") {
        Frame {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Highlight(RoundedCornerShape(50), "Minimizar") {
                    Row(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).background(C.Control).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = C.Text); Text(" Minimizar", style = T.BodyStrong)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Highlight(CircleShape, "Bloquear") { RoundIconButton(Icons.Rounded.Lock, "Bloquear controles", Modifier.size(56.dp)) {} }
                PillButton("Pausar", color = C.Red, icon = Icons.Rounded.Pause, big = true, modifier = Modifier.weight(1f)) {}
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(36.dp), "Terminar") { PillButton("Terminar", color = C.Blue, icon = Icons.Rounded.Stop, big = true, modifier = Modifier.fillMaxWidth()) {} } }
            }
        }
        Frame {
            Highlight(RoundedCornerShape(36.dp), "Guardar actividad") {
                PillButton("Guardar actividad", color = C.Green, icon = Icons.Rounded.Check, big = true, modifier = Modifier.fillMaxWidth()) {}
            }
            Spacer(Modifier.height(8.dp))
            PillButton("Descartar", color = C.Control, textColor = C.Red, icon = Icons.Rounded.DeleteOutline, modifier = Modifier.fillMaxWidth()) {}
        }
        Frame {
            Text("Si minimizas, vuelves desde Inicio:", style = T.Label); Spacer(Modifier.height(8.dp))
            Highlight(RoundedCornerShape(36.dp), "Volver a la actividad") {
                PillButton("Volver a la actividad", color = C.Green, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {}
            }
        }
    },
    Slide("Rutas", "Elige tu municipio y guarda una ruta con la estrella.") {
        Frame {
            Highlight(RoundedCornerShape(26.dp), "Municipio") {
                FCard { Text("Zona", style = T.Label); Text("Elige municipio", style = T.Section) }
            }
            Spacer(Modifier.height(10.dp))
            FCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Ruta del parque", style = T.BodyStrong); Text("5,2 km · Circular · Tierra", style = T.Label) }
                    Highlight(CircleShape, "Favorita") { Icon(Icons.Rounded.Star, "Favorita", tint = C.Amber, modifier = Modifier.padding(8.dp)) }
                }
            }
        }
        Frame {
            Text("Aún no hay rutas verificadas para esta zona", style = T.BodyStrong)
            Text("Te proponemos una sesión por duración o distancia.", style = T.Label)
            Spacer(Modifier.height(8.dp))
            PillButton("Preparar esta sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.PlayArrow, modifier = Modifier.fillMaxWidth()) {}
        }
    },
    Slide("Club", "Organiza una salida o únete con una invitación. Tu recorrido sigue siendo privado.") {
        Frame {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(30.dp), "Crear salida") { PillButton("Crear salida", color = C.Text, textColor = C.Bg, icon = Icons.Rounded.Add, modifier = Modifier.fillMaxWidth()) {} } }
                Box(Modifier.weight(1f)) { Highlight(RoundedCornerShape(30.dp), "Unirme con código") { PillButton("Unirme con código", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) {} } }
            }
        }
    },
    Slide("Rutinas", "Toca un día para planificar una sesión o cambiarla de fecha.") {
        Frame {
            listOf(Triple("Lunes", "Rodaje suave · 30 min", C.Grey), Triple("Martes", "Descanso", null), Triple("Miércoles", "Sendero llano · 45 min", C.Green)).forEachIndexed { i, (d, t, col) ->
                Text(d, style = T.Label, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp, top = if (i > 0) 8.dp else 0.dp))
                val row: @Composable () -> Unit = {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Card).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(col ?: C.Control)); Spacer(Modifier.width(12.dp))
                        Text(t, style = T.BodyStrong, modifier = Modifier.weight(1f)); Icon(Icons.Rounded.MoreHoriz, null, tint = C.TextSec)
                    }
                }
                if (i == 0) Highlight(RoundedCornerShape(24.dp), "Sesión") { row() } else row()
            }
        }
    },
    Slide("Progreso", "Filtra por deporte y periodo. Toca una sesión para ver el mapa y tus tiempos.") {
        Frame {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Highlight(RoundedCornerShape(50), "Periodo") {
                    Row(Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(50)).background(C.Control).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Semana", style = T.BodyStrong); Icon(Icons.Rounded.ExpandMore, null, tint = C.Text)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            MenuPreview {
                MenuTitle("Periodo")
                MenuRow("Semana", Icons.Rounded.DateRange, selected = true) {}
                MenuRow("Mes", Icons.Rounded.DateRange) {}
                MenuRow("Año", Icons.Rounded.DateRange) {}
            }
            Spacer(Modifier.height(10.dp))
            Highlight(RoundedCornerShape(28.dp), "Actividad guardada") {
                RunRow(RunEntity(startedAtWall = System.currentTimeMillis(), status = RunStatus.FINISHED, distanceM = 5230.0, activeMs = 1_820_000, sport = Sport.RUN.name)) {}
            }
        }
    },
    Slide("Perfil y copia", "Inicia sesión para recuperar tus actividades si cambias de móvil. En Apariencia eliges el tema.") {
        Frame {
            FCard {
                Highlight(RoundedCornerShape(20.dp), "Cuenta") { ListRow("Cuenta", "Iniciar sesión o crear cuenta", leading = Icons.Rounded.AccountCircle) {} }
                ListRow("Sincronizado", "Última copia confirmada: hoy", leading = Icons.Rounded.CloudDone, leadingTint = C.Green, trailing = null)
                Highlight(RoundedCornerShape(20.dp), "Apariencia") { ListRow("Apariencia", "Automático", leading = Icons.Rounded.BrightnessAuto) {} }
            }
        }
    },
)

/** Marco de «captura»: contenido real de la app, inerte (absorbe los toques) y adaptado al tema. */
@Composable
private fun Frame(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(C.Surface).border(1.dp, C.Border, RoundedCornerShape(28.dp))) {
        // Estado de desenfoque propio y vacío: el vidrio de la barra de ejemplo no lee la capa de la pantalla real.
        CompositionLocalProvider(LocalHaze provides remember { dev.chrisbanes.haze.HazeState() }) {
            Column(Modifier.fillMaxWidth().padding(14.dp).clearAndSetSemantics { contentDescription = "Ejemplo de la pantalla" }, content = content)
        }
        Box(Modifier.matchParentSize().pointerInput(Unit) { detectTapGestures { } })
    }
}

/** Recorte resaltado del control que hay que tocar. */
@Composable
private fun Highlight(shape: androidx.compose.ui.graphics.Shape, label: String, content: @Composable () -> Unit) {
    Box(Modifier.border(3.dp, C.Blue, shape).padding(4.dp).semantics { contentDescription = "Resaltado: $label" }) { content() }
}

/** Menú abierto tal y como se despliega en la app (mismo material de vidrio). */
@Composable
private fun MenuPreview(content: @Composable ColumnScope.() -> Unit) {
    // Dentro de la propia capa de contenido no se aplica desenfoque (evita que el vidrio se lea a sí mismo):
    // se usa la película translúcida de respaldo del mismo material.
    val shape = RoundedCornerShape(28.dp)
    Column(Modifier.fillMaxWidth(0.92f).clip(shape).background(C.GlassFallback)
        .border(1.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(C.EdgeTop, C.EdgeBottom)), shape).padding(8.dp), content = content)
}
