package app.fuckrun.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import app.fuckrun.domain.OnboardingAnswers
import app.fuckrun.domain.Sport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.store by preferencesDataStore("profile")
private val Context.deviceStore by preferencesDataStore("device")

@Serializable
enum class PrimaryMetric(val label: String) {
    TIME("Tiempo activo"), DISTANCE("Distancia"), PACE("Ritmo actual"), SPEED("Velocidad actual"), ELEVATION("Desnivel positivo");

    companion object {
        fun defaultFor(s: Sport) = when (s) { Sport.RUN -> PACE; Sport.BIKE -> SPEED; Sport.HIKE -> DISTANCE; Sport.WALK -> TIME }
        fun optionsFor(s: Sport) = when (s) {
            Sport.HIKE -> listOf(DISTANCE, ELEVATION, TIME, PACE, SPEED)
            Sport.BIKE -> listOf(SPEED, DISTANCE, TIME)
            else -> listOf(PACE, DISTANCE, TIME, SPEED)
        }
    }
}

@Serializable enum class Appearance(val label: String) { LIGHT("Claro"), DARK("Oscuro"), AUTO("Automático") }

@Serializable
enum class MusicProvider(val label: String) { SPOTIFY("Spotify"), APPLE("Apple Music"), AMAZON("Amazon Music"), NONE("Sin música") }

@Serializable
data class AppSettings(
    val onboardingDone: Boolean = false,
    /** Respuestas de Correr (campo histórico). Los demás deportes viven en [answersBySport]. */
    val answers: OnboardingAnswers = OnboardingAnswers(),
    val answersBySport: Map<Sport, OnboardingAnswers> = emptyMap(),
    val primaryMetric: PrimaryMetric = PrimaryMetric.TIME,
    val primaryMetricBySport: Map<Sport, PrimaryMetric> = emptyMap(),
    val countdown: Boolean = true,
    val remindersEnabled: Boolean = true,
    val sharedDisplayName: String = "",
    val appearance: Appearance = Appearance.AUTO,
    /** Último deporte elegido para una actividad LIBRE (no se toca al empezar desde rutina, ruta o encuentro). */
    val lastFreeSport: Sport = Sport.RUN,
    val music: MusicProvider? = null,
    /** Indicaciones de un solo paso ya vistas (registro manual, invitar, métrica, exportar, descartar). */
    val hintsSeen: Set<String> = emptySet(),
    val updatedAt: Long = 0,
) {
    fun answersFor(s: Sport): OnboardingAnswers = if (s == Sport.RUN) answers else answersBySport[s] ?: answers.copy(
        runsNow = app.fuckrun.domain.RunsNow.NO, daysPerWeekNow = null, continuous = app.fuckrun.domain.Continuous.UNKNOWN,
        usualDistance = app.fuckrun.domain.UsualDistance.UNKNOWN, levelOverride = null, goal = app.fuckrun.domain.Goal.CONSISTENCY,
        targetDistance = null,
    )
    fun withAnswers(s: Sport, a: OnboardingAnswers) = if (s == Sport.RUN) copy(answers = a) else copy(answersBySport = answersBySport + (s to a))
    fun metricFor(s: Sport): PrimaryMetric = primaryMetricBySport[s] ?: PrimaryMetric.defaultFor(s)
}

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = false; coerceInputValues = true }

/**
 * Preferencias sincronizables. Cada perfil local (invitado o cuenta) tiene su propia clave, así que cambiar de
 * cuenta aísla también las preferencias. El invitado conserva la clave histórica para no perder nada al actualizar.
 */
class ProfileStore(private val ctx: Context, accountUid: String?) {
    private val KEY = stringPreferencesKey(if (accountUid == null) "settings_json" else "settings_json_$accountUid")
    /** Se llama tras cada cambio para programar la copia en la cuenta. */
    var onChange: () -> Unit = {}

    val settings: Flow<AppSettings> = ctx.store.data.map { p -> decode(p[KEY]) }

    private fun decode(s: String?) = s?.let { runCatching { AppJson.decodeFromString<AppSettings>(it) }.getOrNull() } ?: AppSettings()

    suspend fun current(): AppSettings = settings.first()

    suspend fun update(f: (AppSettings) -> AppSettings) {
        ctx.store.edit { p -> p[KEY] = AppJson.encodeToString(f(decode(p[KEY])).copy(updatedAt = System.currentTimeMillis())) }
        onChange()
    }

    /** Sustituye por la copia restaurada sin marcarla como cambio local. */
    suspend fun replaceFromRemote(s: AppSettings) { ctx.store.edit { p -> p[KEY] = AppJson.encodeToString(s) } }

    suspend fun raw(): String? = ctx.store.data.first()[KEY]

    suspend fun clear() { ctx.store.edit { it.remove(KEY) }; onChange() }
}

/**
 * Datos que pertenecen al DISPOSITIVO y nunca se sincronizan: tutorial visto, bienvenida vista, cuenta activa
 * y estado de la última copia confirmada.
 */
class DeviceStore(private val ctx: Context) {
    private val TUTORIAL = booleanPreferencesKey("tutorial_seen")
    private val WELCOME = booleanPreferencesKey("welcome_seen")
    private val MERGE_ASKED = stringSetPreferencesKey("guest_merge_asked")

    val tutorialSeen: Flow<Boolean> = ctx.deviceStore.data.map { it[TUTORIAL] == true }
    val welcomeSeen: Flow<Boolean> = ctx.deviceStore.data.map { it[WELCOME] == true }
    suspend fun setTutorialSeen(v: Boolean) { ctx.deviceStore.edit { it[TUTORIAL] = v } }
    suspend fun setWelcomeSeen() { ctx.deviceStore.edit { it[WELCOME] = true } }

    suspend fun mergeAsked(uid: String) = uid in (ctx.deviceStore.data.first()[MERGE_ASKED] ?: emptySet())
    suspend fun setMergeAsked(uid: String) { ctx.deviceStore.edit { it[MERGE_ASKED] = (it[MERGE_ASKED] ?: emptySet()) + uid } }

    private fun settingsKey(uid: String) = longPreferencesKey("settings_synced_$uid")
    suspend fun settingsSyncedAt(uid: String): Long = ctx.deviceStore.data.first()[settingsKey(uid)] ?: 0L
    suspend fun setSettingsSyncedAt(uid: String, at: Long) { ctx.deviceStore.edit { it[settingsKey(uid)] = at } }

    private fun syncKey(uid: String) = longPreferencesKey("last_sync_$uid")
    fun lastSync(uid: String): Flow<Long?> = ctx.deviceStore.data.map { it[syncKey(uid)] }
    suspend fun setLastSync(uid: String, at: Long) { ctx.deviceStore.edit { it[syncKey(uid)] = at } }
}
