package app.fuckrun.data

import android.content.Context
import app.fuckrun.domain.*
import app.fuckrun.domain.metrics.RunMetrics
import kotlinx.serialization.Serializable
import java.text.Normalizer

data class Municipality(val cpro: String, val province: String, val name: String) {
    val key get() = "$cpro|$name"
    val display get() = "$name · $province"
}

class MunicipalityIndex(ctx: Context) {
    val all: List<Municipality> = ctx.assets.open("municipios.csv").bufferedReader().useLines { lines ->
        lines.filter { it.isNotBlank() && !it.startsWith("#") && !it.startsWith("cpro") }.mapNotNull { line ->
            val parts = Regex("\"([^\"]*)\"|([^,]+)").findAll(line).map { it.groupValues[1].ifEmpty { it.groupValues[2] } }.toList()
            if (parts.size >= 3) Municipality(parts[0].trim(), parts[1].trim(), parts[2].trim()) else null
        }.toList()
    }
    private val duplicated = all.groupBy { norm(it.name) }.filterValues { it.size > 1 }.keys

    fun isAmbiguous(m: Municipality) = norm(m.name) in duplicated

    fun search(q: String, limit: Int = 40): List<Municipality> {
        val n = norm(q)
        if (n.isBlank()) return all.take(limit)
        return all.filter { norm(it.name).contains(n) || norm(it.province).contains(n) }
            .sortedWith(compareBy({ !norm(it.name).startsWith(n) }, { it.name }, { it.province })).take(limit)
    }

    companion object {
        fun norm(s: String) = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}"), "").lowercase()
    }
}

@Serializable data class LatLon(val lat: Double, val lon: Double)
@Serializable data class RouteSource(val name: String, val license: String, val url: String? = null)
@Serializable data class RouteIncident(val text: String, val date: String)
@Serializable data class RouteStart(val lat: Double, val lon: Double, val label: String)

/** Un recorrido solo entra en el catálogo si sus datos se han verificado. Campos desconocidos = null. */
@Serializable
data class VerifiedRoute(
    val id: String,
    val name: String,
    val municipality: String,
    val province: String,
    val cpro: String,
    val shape: RouteShape,                 // LOOP u OUT_BACK
    val distanceM: Double,
    val surface: String? = null,
    val elevationGainM: Double? = null,    // solo con fuente fiable
    val start: RouteStart,
    val track: List<LatLon>,
    val environments: List<Environment> = emptyList(),
    val source: RouteSource,
    val reviewedAt: String,
    val incidents: List<RouteIncident> = emptyList(),
    /** Atributos como "iluminada" o "accesible" solo aparecen si se han verificado. */
    val verifiedAttributes: List<String> = emptyList(),
    /**
     * Deportes verificados (Sport.name). null = sin dato: se trata como recorrido a pie (Correr, Sendero, Caminata).
     * Nunca se supone que una ruta a pie admite bicicleta.
     */
    val sports: List<String>? = null,
)

data class RouteFilter(
    val sport: String? = null,
    val minKm: Double? = null, val maxKm: Double? = null,
    val surface: String? = null, val flatOnly: Boolean = false, val maxDistanceFromMeKm: Double? = null,
)

data class RankedRoute(val route: VerifiedRoute, val score: Int, val distanceFromMeM: Double?)

class RouteCatalog(ctx: Context) {
    val routes: List<VerifiedRoute> = runCatching {
        ctx.assets.list("routes")!!.filter { it.endsWith(".json") }.map { f ->
            AppJson.decodeFromString(VerifiedRoute.serializer(), ctx.assets.open("routes/$f").bufferedReader().readText())
        }
    }.getOrDefault(emptyList())

    fun byId(id: String?) = routes.firstOrNull { it.id == id }

    fun forMunicipality(m: Municipality?) =
        if (m == null) routes else routes.filter { it.cpro == m.cpro && MunicipalityIndex.norm(it.municipality) == MunicipalityIndex.norm(m.name) }

    val surfaces get() = routes.mapNotNull { it.surface }.distinct()

    /** Criterio: entorno preferido (+2), forma preferida (+1), llano si se prefiere y hay dato (+1); desempate por cercanía. */
    fun rank(list: List<VerifiedRoute>, a: OnboardingAnswers, f: RouteFilter, me: LatLon?): List<RankedRoute> =
        list.asSequence()
            .filter { r -> f.sport == null || (r.sports ?: listOf("RUN", "HIKE", "WALK")).contains(f.sport) }
            .filter { f.minKm == null || it.distanceM >= f.minKm * 1000 }
            .filter { f.maxKm == null || it.distanceM <= f.maxKm * 1000 }
            .filter { f.surface == null || it.surface == f.surface }
            .filter { !f.flatOnly || (it.elevationGainM != null && it.elevationGainM < 30) }
            .map { r ->
                val dist = me?.let { RunMetrics.haversine(it.lat, it.lon, r.start.lat, r.start.lon) }
                var s = 0
                if (r.environments.any { it in a.environments }) s += 2
                if (a.routeShape != RouteShape.ANY && r.shape == a.routeShape) s += 1
                if (a.elevation == Elevation.FLAT && r.elevationGainM != null && r.elevationGainM < 30) s += 1
                RankedRoute(r, s, dist)
            }
            .filter { f.maxDistanceFromMeKm == null || (it.distanceFromMeM != null && it.distanceFromMeM <= f.maxDistanceFromMeKm * 1000) }
            .sortedWith(compareByDescending<RankedRoute> { it.score }.thenBy { it.distanceFromMeM ?: Double.MAX_VALUE })
            .toList()

    fun criterion(a: OnboardingAnswers): String = buildString {
        append("Ordenado por: ")
        val parts = mutableListOf<String>()
        if (a.environments.isNotEmpty()) parts += "entorno preferido (${a.environments.joinToString { it.label.lowercase() }})"
        if (a.routeShape != RouteShape.ANY) parts += "forma ${a.routeShape.label.lowercase()}"
        if (a.elevation == Elevation.FLAT) parts += "llano (si hay dato fiable)"
        parts += "cercanía, si has compartido tu ubicación"
        append(parts.joinToString(", "))
    }
}
