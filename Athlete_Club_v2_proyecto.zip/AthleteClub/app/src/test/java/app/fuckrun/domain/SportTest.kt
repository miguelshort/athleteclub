package app.fuckrun.domain

import app.fuckrun.domain.metrics.RunMetrics
import app.fuckrun.domain.metrics.RunMetrics.Interval
import app.fuckrun.domain.metrics.RunMetrics.Sample
import org.junit.Assert.*
import org.junit.Test

class SportTest {
    private val degPerM = 1.0 / 111_320.0

    private fun line(n: Int, mps: Double, alt: (Int) -> Double? = { null }) =
        (0 until n).map { i -> Sample(0, i * 1000L, i * 1000L, 40.0 + i * mps * degPerM, -3.0, 5f, alt(i)) }

    @Test fun historicRunsMigrateAsRun() {
        assertEquals(Sport.RUN, Sport.of(null))
        assertEquals(Sport.RUN, Sport.of("desconocido"))
        assertEquals(Sport.BIKE, Sport.of("BIKE"))
        assertEquals(listOf("Correr", "Sendero", "Bicicleta", "Caminata"), Sport.entries.map { it.label })
    }

    @Test fun fastCyclingIsKeptWithBikeLimit() {
        val pts = line(120, 16.7)   // ~60 km/h: antes se descartaba con el límite global de 45 km/h
        val run = RunMetrics.compute(pts, listOf(Interval(0, 119_000)), 0, 119_000, 119_000, maxPlausibleMps = SportRules.maxPlausibleMps(Sport.RUN))
        val bike = RunMetrics.compute(pts, listOf(Interval(0, 119_000)), 0, 119_000, 119_000, maxPlausibleMps = SportRules.maxPlausibleMps(Sport.BIKE))
        assertTrue("con el límite de correr casi todo se descarta", run.distanceM < 100)
        assertEquals(119 * 16.7, bike.distanceM, 119 * 16.7 * 0.03)
        assertEquals(16.7 * 3.6, (bike.avgSpeedMps ?: 0.0) * 3.6, 1.5)
    }

    @Test fun elevationOnlyWhenReliable() {
        val noAlt = RunMetrics.compute(line(60, 1.2), listOf(Interval(0, 59_000)), 0, 59_000, 59_000)
        assertNull(noAlt.elevationGainM)
        // Subida constante de 0,5 m por segundo durante 60 s => ~30 m
        val climb = RunMetrics.compute(line(61, 1.2) { it * 0.5 }, listOf(Interval(0, 60_000)), 0, 60_000, 60_000)
        assertEquals(30.0, climb.elevationGainM ?: -1.0, 4.0)
        // Ruido de ±1,5 m sin desnivel real => casi 0
        val noisy = RunMetrics.compute(line(120, 1.2) { if (it % 2 == 0) 101.5 else 98.5 }, listOf(Interval(0, 119_000)), 0, 119_000, 119_000)
        assertTrue((noisy.elevationGainM ?: 99.0) < 2.0)
    }

    @Test fun recommendationsPerSport() {
        val a = OnboardingAnswers(sessionMinutes = 60, desiredDays = 3)
        Sport.entries.forEach { s ->
            val p = RecommendationEngine.proposal(a, s)
            assertTrue(p.mainMinutes in 5..60)
            assertTrue(p.usedAnswers.isNotEmpty())
            val w = RecommendationEngine.weekly(a, s)
            assertTrue(w.days.isNotEmpty())
        }
        assertEquals(Templates.WALK_RUN.id, RecommendationEngine.proposal(a, Sport.RUN).templateId)
        assertEquals(Templates.HIKE.id, RecommendationEngine.proposal(a, Sport.HIKE).templateId)
        assertEquals(Templates.BIKE.id, RecommendationEngine.proposal(a, Sport.BIKE).templateId)
        assertEquals(Templates.WALK.id, RecommendationEngine.proposal(a, Sport.WALK).templateId)
    }

    @Test fun noDataIsEmDash() { assertEquals("—", Fmt.pace(null)); assertEquals("—", Fmt.km(null)) }
}
