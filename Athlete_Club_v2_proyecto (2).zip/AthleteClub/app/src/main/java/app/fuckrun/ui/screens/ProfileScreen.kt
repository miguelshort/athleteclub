package app.fuckrun.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import app.fuckrun.FuckrunApp
import app.fuckrun.Routes
import app.fuckrun.data.*
import app.fuckrun.data.account.AccountState
import app.fuckrun.data.account.SyncStatus
import app.fuckrun.data.db.AppDatabase
import app.fuckrun.data.db.TombstoneEntity
import app.fuckrun.BuildConfig
import app.fuckrun.domain.Fmt
import app.fuckrun.data.account.GuestMerger
import app.fuckrun.domain.LevelClassifier
import app.fuckrun.domain.Sport
import app.fuckrun.domain.Templates
import app.fuckrun.offerGuestMerge
import app.fuckrun.reminders.Reminders
import app.fuckrun.tracking.Tracking
import app.fuckrun.ui.components.*
import app.fuckrun.ui.theme.C
import app.fuckrun.ui.theme.T
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId

@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    val app = FuckrunApp.instance
    val g = FuckrunApp.graph
    val sheet = LocalSheet.current
    val scope = rememberCoroutineScope()
    val s by g.profile.settings.collectAsStateWithLifecycle(AppSettings())
    val account by app.account.state.collectAsStateWithLifecycle()
    val sync by app.sync.status.collectAsStateWithLifecycle()
    val live by Tracking.live.collectAsStateWithLifecycle()
    val guestRuns by produceState(0, g) { value = g.runs.finishedCount() }
    fun appSettings() = runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))) }
    fun busyRun(): Boolean { if (live != null) { sheet.dialog { Text("Termina antes la actividad en curso.", style = T.Body); Spacer(Modifier.height(12.dp))
        PillButton("Entendido", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide() } }; return true }; return false }

    ScreenScaffold("Perfil", header = { RoundIconButton(Icons.Rounded.Close, "Cerrar") { nav.popBackStack() } }) {
        // ---------- Cuenta ----------
        item { SectionTitle("Cuenta") }
        item {
            FCard {
                when (val a = account) {
                    AccountState.NotConfigured -> {
                        ListRow("Sin cuenta", "La cuenta no está configurada en esta versión. Todo funciona en este móvil.", leading = Icons.Rounded.PhoneAndroid, trailing = null)
                    }
                    AccountState.Guest, is AccountState.ClubOnly -> {
                        Text("Tus actividades están en este móvil. Crea una cuenta para recuperarlas si reinstalas la app.", style = T.Body.copy(color = C.TextSec))
                        Spacer(Modifier.height(12.dp))
                        PillButton("Crear cuenta", color = C.Green, icon = Icons.Rounded.PersonAdd, modifier = Modifier.fillMaxWidth()) { if (!busyRun()) nav.navigate(Routes.account("create")) }
                        Spacer(Modifier.height(8.dp))
                        PillButton("Iniciar sesión", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Login, modifier = Modifier.fillMaxWidth()) { if (!busyRun()) nav.navigate(Routes.account("signin")) }
                        Text("Ahora usas Athlete Club sin cuenta.", style = T.Label, modifier = Modifier.padding(top = 8.dp))
                    }
                    is AccountState.SignedIn -> {
                        ListRow(a.username.ifBlank { "Tu cuenta" }, a.email, leading = Icons.Rounded.AccountCircle, trailing = null)
                        if (!a.verified) {
                            Notice("Verifica tu correo: te hemos enviado un enlace.", icon = Icons.Rounded.MarkEmailUnread)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PillButton("Ya lo he verificado", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) {
                                    scope.launch { runCatching { app.account.refresh() } }
                                }
                                PillButton("Reenviar", color = C.Control, textColor = C.Text, modifier = Modifier.weight(1f)) {
                                    scope.launch { runCatching { app.account.resendVerification() } }
                                }
                            }
                        }
                        ListRow("Cerrar sesión", "Tus datos siguen en la cuenta. En este móvil verás el modo sin cuenta.", leading = Icons.Rounded.Logout) {
                            if (!busyRun()) sheet.confirm("¿Cerrar sesión?", "Podrás volver a entrar con tu correo y contraseña. Las actividades no copiadas se subirán la próxima vez que entres.",
                                "Cerrar sesión", C.Blue) { app.account.signOut() }
                        }
                        ListRow("Llevar actividades del modo sin cuenta", "Solo se añaden las que confirmes", leading = Icons.Rounded.MoveDown) {
                            scope.launch {
                                val n = withContext(Dispatchers.IO) { val gdb = AppDatabase.build(ctx.applicationContext, null); try { GuestMerger.guestCount(gdb) } finally { gdb.close() } }
                                if (n == 0) sheet.dialog { Text("No hay actividades sin cuenta en este móvil.", style = T.Body); Spacer(Modifier.height(12.dp))
                                    PillButton("Entendido", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide() } }
                                else offerGuestMerge(sheet, n, a.uid, scope)
                            }
                        }
                        ListRow("Eliminar la cuenta", "Borra la cuenta y su copia en el servidor", leading = Icons.Rounded.PersonRemove, leadingTint = C.Red) {
                            if (!busyRun()) sheet.confirm("¿Eliminar tu cuenta?",
                                "Se borrará tu copia privada en el servidor, se cancelarán tus encuentros y se eliminará la cuenta. No se puede deshacer.", "Eliminar la cuenta", C.Red) {
                                scope.launch { deleteAccount(a.uid) { msg -> sheet.dialog { Text(msg, style = T.Body); Spacer(Modifier.height(12.dp))
                                    PillButton("Entendido", color = C.Control, textColor = C.Text, modifier = Modifier.fillMaxWidth()) { sheet.hide() } } } }
                            }
                        }
                    }
                }
            }
        }
        // ---------- Copia ----------
        item { SectionTitle("Copia de seguridad") }
        item {
            FCard {
                val (title, sub, icon, color) = syncText(sync, guestRuns)
                ListRow(title, sub, leading = icon, leadingTint = color, trailing = null)
                if (sync is SyncStatus.Error || sync is SyncStatus.Pending) PillButton("Reintentar", color = C.Control, textColor = C.Text, icon = Icons.Rounded.Refresh) { app.sync.request() }
            }
        }
        // ---------- Apariencia, música y ayuda ----------
        item { SectionTitle("Ajustes") }
        item {
            FCard {
                ListRow("Apariencia", s.appearance.label, leading = if (C.isDark) Icons.Rounded.DarkMode else Icons.Rounded.LightMode) {
                    sheet.pick("Apariencia", Appearance.entries, { it.label }, s.appearance, icon = { when (it) {
                        Appearance.LIGHT -> Icons.Rounded.LightMode; Appearance.DARK -> Icons.Rounded.DarkMode; Appearance.AUTO -> Icons.Rounded.BrightnessAuto } },
                        subtitle = { if (it == Appearance.AUTO) "Sigue al sistema" else null }) { v -> scope.launch { g.profile.update { it.copy(appearance = v) } } }
                }
                ListRow("Música", s.music?.label ?: "Elegir", leading = Icons.Rounded.MusicNote) {
                    sheet.pick("Música", MusicProvider.entries, { it.label }, s.music, icon = { if (it == MusicProvider.NONE) Icons.Rounded.MusicOff else Icons.Rounded.MusicNote }) { v ->
                        scope.launch { g.profile.update { it.copy(music = v) } }
                    }
                }
                ListRow("Cómo se usa", "Repite el tutorial", leading = Icons.Rounded.HelpOutline) { nav.navigate(Routes.tutorial(replay = true)) }
                ListRow("Unidades", "km, m, km/h y min/km", leading = Icons.Rounded.Straighten, trailing = null)
                ToggleRow("Cuenta atrás antes de empezar", s.countdown) { v -> scope.launch { g.profile.update { it.copy(countdown = v) } } }
            }
        }
        // ---------- Formulario por deporte ----------
        item { SectionTitle("Tu nivel por deporte") }
        item {
            FCard {
                Sport.entries.forEach { sp ->
                    val lvl = LevelClassifier.classify(s.answersFor(sp), sp).level
                    ListRow(sp.label, "Nivel orientativo: ${lvl.label}", leading = sp.icon, leadingTint = sp.color) { nav.navigate(Routes.onboarding(sp.name)) }
                }
                ListRow("Ciudad", listOfNotNull(s.answers.municipality, s.answers.province).joinToString(", ").ifBlank { "Sin elegir" }, leading = Icons.Rounded.Place) {
                    sheet.page("Municipio") {
                        MunicipalityPicker(null) { m -> scope.launch { g.profile.update { it.copy(answers = it.answers.copy(municipality = m?.name, province = m?.province)) } }; sheet.hide() }
                    }
                }
            }
        }
        // ---------- Permisos ----------
        item { SectionTitle("Permisos y avisos") }
        item {
            FCard {
                ListRow("Ubicación", when { Tracking.hasLocationPermission(ctx) -> "Precisa, solo mientras usas la app"; Tracking.hasCoarsePermission(ctx) -> "Solo aproximada"
                    else -> "No concedida" }, leading = Icons.Rounded.LocationOn) { appSettings() }
                ListRow("Notificaciones", if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) "Activadas" else "Desactivadas", leading = Icons.Rounded.Notifications) { appSettings() }
                ToggleRow("Recordatorios de rutina", s.remindersEnabled) { v -> scope.launch { g.profile.update { it.copy(remindersEnabled = v) }; Reminders.rescheduleAll(ctx) } }
            }
        }
        // ---------- Datos ----------
        item { SectionTitle("Tus datos") }
        item {
            FCard {
                Text("Tus actividades son privadas. No hay feed, seguidores, «me gusta», comentarios ni clasificaciones. Unirte a un encuentro no comparte tu ruta, ritmo ni posición.",
                    style = T.Label)
                Spacer(Modifier.height(6.dp))
                ListRow("Exportar mis datos (JSON)", "Actividades con su deporte, rutinas y ajustes", leading = Icons.Rounded.Download) {
                    privacyWarning(sheet) {
                        scope.launch {
                            val runs = g.runs.finishedRuns().first()
                            val all = Exporter.ExportAll(exportedAt = System.currentTimeMillis(), settings = g.profile.settings.first(),
                                runs = runs.map { Exporter.exportRun(it, g.runs.points(it.id)) },
                                planned = g.routines.plannedOnce().map { Exporter.ExportPlanned(it.id, it.routineId, it.name, it.epochDay, it.type, it.targetMinutes, it.targetKm, it.linkedRunId, it.sport) })
                            Exporter.share(ctx, "athlete-club-datos.json", "application/json", Exporter.json(all))
                        }
                    }
                }
                ListRow("Borrar todas mis actividades y rutinas", "De este perfil; si tienes cuenta, también de su copia", leading = Icons.Rounded.DeleteForever, leadingTint = C.Red) {
                    if (!busyRun()) sheet.confirm("¿Borrar todos tus datos?", "Se borrarán actividades, rutinas, favoritos y respuestas de este perfil. No se puede deshacer. Tu cuenta no se elimina.", "Borrar todo", C.Red) {
                        scope.launch {
                            g.runs.deleteAll(); g.routines.deleteAll()
                            g.db.favorites().allOnce().forEach { g.db.tombstones().put(TombstoneEntity("fav:${it.routeId}", "FAVORITE")) }
                            g.db.favorites().deleteAll(); g.profile.clear()
                            Reminders.rescheduleAll(ctx)
                            nav.navigate(Routes.HOME) { popUpTo(0) }
                        }
                    }
                }
            }
        }
        item { SectionTitle("Acerca de") }
        item {
            FCard {
                Text("Athlete Club ${BuildConfig.VERSION_NAME}. Mapas: ${BuildConfig.MAP_ATTRIBUTION}. Tipografía Inter (SIL Open Font License).", style = T.Label)
                Spacer(Modifier.height(6.dp))
                Text("Plantillas: " + Templates.all.joinToString(" ") { "${it.name}: ${it.source}" }, style = T.Label)
                Spacer(Modifier.height(6.dp))
                Text("Athlete Club no usa inteligencia artificial: las propuestas salen de reglas explícitas y revisables.", style = T.Label)
            }
        }
    }
}

private data class SyncLine(val title: String, val sub: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val color: androidx.compose.ui.graphics.Color)

@Composable
private fun syncText(s: SyncStatus, localRuns: Int): SyncLine {
    fun at(t: Long?) = t?.let { val d = Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()); "Última copia confirmada: ${Fmt.date(d.toLocalDate())}, ${"%02d:%02d".format(d.hour, d.minute)}" }
        ?: "Todavía no hay ninguna copia confirmada"
    return when (s) {
        SyncStatus.NotConfigured -> SyncLine("Sin copia", "La cuenta no está configurada en esta versión. Tus $localRuns actividades están en este móvil.", Icons.Rounded.CloudOff, C.TextSec)
        SyncStatus.Guest -> SyncLine("Sin copia", "Tus actividades están en este móvil. Crea una cuenta para recuperarlas si reinstalas la app.", Icons.Rounded.PhoneAndroid, C.TextSec)
        is SyncStatus.Synced -> SyncLine("Sincronizado", at(s.at), Icons.Rounded.CloudDone, C.Green)
        is SyncStatus.Running -> SyncLine("Copiando…", at(s.lastAt), Icons.Rounded.CloudSync, C.TextSec)
        is SyncStatus.Pending -> SyncLine("Pendiente de conexión", at(s.lastAt), Icons.Rounded.CloudQueue, C.Amber)
        is SyncStatus.Error -> SyncLine("Error · Reintentar", "${s.message}. ${at(s.lastAt)}", Icons.Rounded.CloudOff, C.Red)
    }
}

/** Distingue claramente: borrar una actividad (Historial), cerrar sesión y eliminar la cuenta (aquí). */
private suspend fun deleteAccount(uid: String, onError: (String) -> Unit) {
    val app = FuckrunApp.instance
    val fs = app.firebase.fs ?: return onError("La cuenta no está configurada.")
    try {
        app.sync.deleteRemote(fs, uid)
        app.graph.shared.deleteAccount()   // cancela encuentros y borra el usuario de autenticación
        app.account.signOut()
        // La copia local se borra cuando la interfaz ya ha pasado al perfil sin cuenta.
        app.appScope.launch { kotlinx.coroutines.delay(20_000); app.deleteLocalProfile(uid) }
    } catch (e: Exception) {
        onError(e.message ?: "No se ha podido eliminar la cuenta. Inténtalo de nuevo.")
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = T.BodyStrong, modifier = Modifier.weight(1f))
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = C.Green, checkedThumbColor = C.OnColor))
    }
}
